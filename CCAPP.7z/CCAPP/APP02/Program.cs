﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Browser;

namespace APP02;

class Program
{
    static void Main(string[] args)
    {
        MssqlR t1 = new MssqlR();
        DataTable dt;
        string url, s1, st1, st2,vsql;
        //string[] a1 = { "西歐", "南歐", "中歐", "東歐", "北歐", "歐洲河輪" };
        int n1, n2, n3, n4, n5;
        n1 = 0;
        n2 = 0;
        n3 = 0;
        n4 = 0;
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> aa4 = new List<string>();
        List<string> aa5 = new List<string>();
        List<string> aa6 = new List<string>();
        List<string> aa7 = new List<string>();
        url = "https://www.travel.com.tw/HALL/Index/EU";
        IWebDriver driver = new ChromeDriver();
        driver.Navigate().GoToUrl(url);
        driver.Manage().Window.Maximize();
        Thread.Sleep(5000);
        s1 = driver.PageSource;
        using (StreamWriter sw = File.CreateText("1.txt"))
        {
            sw.WriteLine(s1);
        }
        driver.Close();
        driver.Quit();
        using (StreamReader sr = new StreamReader("1.txt"))
        {
            string line;
            while (((line = sr.ReadLine()) != null) & (n2 == 0))
            {
                if (line.IndexOf("</a>西歐</h4>") > 0)
                {
                    n1 = 1;
                }
                if (line.IndexOf("</a>歐洲河輪</h4>") > 0)
                {
                    n1 = 0;
                    n2 = 1;
                }
                if ((n1 == 1) & (line != ""))
                {
                    aa1.Add(line.Trim());
                }
            }
            n1 = 0;
            n2 = aa1.Count - 1;
            using (StreamWriter sw = File.CreateText("2.txt"))
            {
                while (n1 <= n2)
                {
                    sw.WriteLine(aa1[n1]);
                    n1++;
                }
            }
            st1 = "";
            st2 = "";
            n1 = 0;
            while (n1 <= n2)
            {
                s1 = aa1[n1];
                if (s1.IndexOf("</a>西歐</h4>") > 0) { st1 = "西歐"; }
                if (s1.IndexOf("</a>南歐</h4>") > 0) { st1 = "南歐"; }
                if (s1.IndexOf("</a>中歐</h4>") > 0) { st1 = "中歐"; }
                if (s1.IndexOf("</a>東歐</h4>") > 0) { st1 = "東歐"; }
                if (s1.IndexOf("</a>北歐</h4>") > 0) { st1 = "北歐"; }
                n3 = s1.IndexOf("<span class=\"iStyle pr-3\">I</span>");
                n4 = s1.IndexOf("<span class=\"iStyle pl-4\">I</span>");
                if ((n3 > 0) & (n4 > 0))
                {
                    st2 = s1.Substring(n3 + 34);
                    n3 = st2.IndexOf("<");
                    st2 = st2.Substring(0, n3);
                }
                n3 = s1.IndexOf("<a href=");
                if (n3 > 0)
                {
                    s1 = s1.Substring(n3 + 9);
                    //Console.WriteLine(s1);
                    n4 = s1.IndexOf("\"");
                    if (n4 > 0)
                    {
                        s1 = s1.Substring(0, n4);
                        aa2.Add(s1);
                        aa3.Add(st1);
                        aa4.Add(st2);
                    }
                }
                n1++;
            }
            n1 = 0;
            n2 = aa2.Count - 1;
            using (StreamWriter sw = File.CreateText("3.txt"))
            {
                while (n1 <= n2)
                {
                    sw.WriteLine(aa2[n1]);
                    n1++;
                }
            }
            n1 = 0;
            n5 = 0;
            while (n1 <= n2)
            {
                st1 = aa2[n1];
                n3 = 0;
                n4 = aa5.Count - 1;
                n5 = 0;
                while ((n3 <= n4) & (n5 == 0))
                {
                    st2 = aa5[n3];
                    if (st1 == st2)
                    {
                        aa6[n3] = aa6[n3] + "," + aa3[n1];
                        aa7[n3] = aa7[n3] + "," + aa4[n1];
                        n5 = 1;
                        n3 = 99999;
                    }
                    n3++;
                }
                if (n5 == 0)
                {
                    aa5.Add(st1);
                    aa6.Add(aa3[n1]);
                    aa7.Add(aa4[n1]);
                }
                n1++;
            }
            n1 = 0;
            n2 = aa5.Count - 1;
            aa1.Clear();
            s1 = "truncate table P01V;";
            aa1.Add(s1);
            t1.RunSQL_TRAN(aa1);
            aa1.Clear();
            while (n1 <= n2)
            {
                s1="insert into P01V (URLPATH,ID01,TAG1,TAG2) values (";
                s1+=t1.QuotedStr("https://www.travel.com.tw"+aa5[n1])+",";
                s1+=t1.QuotedStr("1")+",";
                s1+=t1.QuotedStr(aa6[n1])+",";
                s1+=t1.QuotedStr(aa7[n1])+");";
                aa1.Add(s1);
                n1++;
            }

            t1.RunSQL_TRAN(aa1);
        }
        vsql = "SELECT COUNT(*) CNT FROM P01V";
        dt = t1.RunSQL(vsql);
        Console.WriteLine(dt.Rows[0]["CNT"].ToString());
    }
}
