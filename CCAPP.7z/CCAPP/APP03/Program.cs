﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;

namespace APP03;

class Program
{
    static void Main(string[] args)
    {
        //int npp = Int32.Parse(args[0]);
        //string spp = args[0];
        string spp = "1";

        //先爬鳳凰旅行社,鳳凰只有1條歐洲線其他不考慮
        MssqlR t1 = new MssqlR();
        DataTable dt;
        string vsql;
        vsql = "SELECT ALLID,URLPATH,TAG1,TAG2,ID01 FROM P01V";
        vsql = vsql + " where ALLID=" + spp;
        dt = t1.RunSQL(vsql);
        int n1, n2, n3, n4, n5, n6, nl;
        n1 = 0;
        n2 = 0;
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> da1 = new List<string>();
        List<string> da2 = new List<string>();
        List<string> da3 = new List<string>();
        List<string> da4 = new List<string>();
        List<string> da5 = new List<string>();
        List<string> da6 = new List<string>();
        List<string> da7 = new List<string>();
        List<string> da8 = new List<string>();
        List<string> da9 = new List<string>();
        List<string> daa = new List<string>();
        List<string> dab = new List<string>();
        string s1, s2, s3, st1, st2, st3, sid01;
        while (n1 <= n2)
        {
            IWebDriver driver = new ChromeDriver();
            s1 = dt.Rows[n1]["ALLID"].ToString();
            s2 = dt.Rows[n1]["URLPATH"].ToString();
            st1 = dt.Rows[n1]["TAG1"].ToString();
            st2 = dt.Rows[n1]["TAG2"].ToString();
            sid01 = dt.Rows[n1]["ID01"].ToString();
            driver.Navigate().GoToUrl(s2);
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);
            s3 = driver.PageSource;
            using (StreamWriter sw = File.CreateText("1.txt"))
            {
                sw.WriteLine(s3);
            }
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        aa1.Add(line);
                    }
                }
            }
            driver.Close();
            driver.Quit();
            n1++;
        }
        n1 = 0;
        n2 = aa1.Count - 1;
        while (n1 <= n2)
        {
            aa2.Add(aa1[n1]);
            n1++;
        }
        n1 = 0;
        while (n1 <= n2)
        {
            s1 = aa1[n1];
            n3 = s1.IndexOf("<a href=");
            n4 = s1.IndexOf("/products");
            n5 = s1.IndexOf("group/search");
            if ((n3 >= 0) & (n4 >= 0) & (n5 < 0))
            {
                nl = 0;
                n6 = n1;
                while (nl == 0)
                {
                    n6++;
                    s1 = s1 + aa2[n6];
                    if (s1.IndexOf("</a>") > 0)
                    {
                        aa3.Add(s1);
                        nl = 1;
                    }
                }
                n1 = n6;
            }
            n1++;
        }
        n1 = 0;
        n2 = aa3.Count - 1;
        aa1.Clear();
        aa2.Clear();
        while (n1 <= n2)
        {
            aa1.Add(aa3[n1]);
            n1++;
        }
        n1 = 0;
        n2 = aa1.Count - 1;
        aa3.Clear();
        while (n1 <= n2)
        {
            s1 = aa1[n1];
            n3 = s1.IndexOf("<a href=");
            if (n3 >= 0)
            {
                s1 = s1.Substring(n3 + 9);
                n4 = s1.IndexOf("\"");
                s1 = s1.Substring(0, n4);
                n4 = s1.IndexOf("ystravel.com.tw");
                if (n4 < 0)
                {
                    s1 = "https://www.ystravel.com.tw" + s1;
                }
                aa2.Add(s1);
            }
            s1 = aa1[n1];
            n3 = s1.IndexOf("<h3");
            n4 = s1.IndexOf("</h3>");
            s1 = s1.Substring(n3, n4 - n3);
            n3 = s1.IndexOf(">");
            s1 = s1.Substring(n3 + 1);
            aa3.Add(s1);
            n1++;
        }
        n1 = 0;
        n2 = aa3.Count - 1;
        using (StreamWriter sw = File.CreateText("1.txt"))
        {
            while (n1 <= n2)
            {
                sw.WriteLine(aa3[n1]);
                n1++;
            }
        }
        aa1.Clear();
        n1 = 0;
        n2 = aa2.Count - 1;
        while (n1 <= n2)
        {
            aa1.Add(aa2[n1]);
            n1++;
        }
        aa2.Clear();
        n1 = 0;
        n2 = aa3.Count - 1;
        while (n1 <= n2)
        {
            aa2.Add(aa3[n1]);
            n1++;
        }
        aa3.Clear();
        n1 = 0;
        n2 = aa1.Count-1;
        while (n1 <= n2)
        {
            IWebDriver driver = new ChromeDriver();
            s1 = aa1[n1];
            st3 = s1;
            driver.Navigate().GoToUrl(s1);
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);
            s2 = driver.PageSource;
            using (StreamWriter sw = File.CreateText("1.txt"))
            {
                sw.WriteLine(s2);
            }
            driver.Close();
            driver.Quit();
            nl = 0;
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    n3 = line.IndexOf("<tr data-prod-idx=");
                    if (n3 > 0) { nl = 1; }
                    n4 = line.IndexOf("</tbody>");
                    if (n4 > 0) { nl = 0; }
                    if (nl == 1)
                    {
                        aa3.Add(line);
                    }
                }
            }
            n3 = 0;
            n4 = aa3.Count - 1;
            while (n3 <= n4)
            {
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "go-date" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 22);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    da1.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("class=" + "\"" + "item_days" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 18);
                    n6 = s1.IndexOf("<");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da2.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("class=" + "\"" + "title_main" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 19);
                    n6 = s1.IndexOf("</a>");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da3.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "plane-abbr" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 25);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da4.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "機位：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da5.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "已售：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da6.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "候補：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da7.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "可售：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    da8.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "text-danger" + "\"" + ">NT$");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    da9.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "text-danger" + "\"" + ">NT$");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    daa.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("btn_book");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 10);
                    n6 = s1.IndexOf("</a>");
                    s1 = s1.Substring(0, n6);
                    n6 = s1.IndexOf(">");
                    if (n6 > 0)
                    {
                        s1 = s1.Substring(n6 + 1);
                    }
                    Console.WriteLine(s1);
                    dab.Add(s1);
                }

                n3++;
            }
            n1++;
        }
        Console.WriteLine(da1.Count);
        Console.WriteLine(da2.Count);
        Console.WriteLine(da3.Count);
        Console.WriteLine(da4.Count);
        Console.WriteLine(da5.Count);
        Console.WriteLine(da6.Count);
        Console.WriteLine(da7.Count);
        Console.WriteLine(da8.Count);
        Console.WriteLine(da9.Count);
        Console.WriteLine(daa.Count);
    }
}
