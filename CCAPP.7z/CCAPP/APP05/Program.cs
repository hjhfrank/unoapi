﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium.Firefox;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;

namespace APP05;

class Program
{
    static void Main(string[] args)
    {
        //int npp = Int32.Parse(args[0]);
        //string spp = args[0];
        string spp = "1";

       
        MssqlR t1 = new MssqlR();
        DataTable dt;
        string vsql;
        vsql = "SELECT ALLID,URLPATH,TAG1,TAG2,ID01 FROM P01V";
        vsql = vsql + " where ALLID=" + spp;
        dt = t1.RunSQL(vsql);
        int n1, n2, n3, n4, n5, n6, nl;
        n1 = 0;      
        n2 = 0;      
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> da1 = new List<string>();
        List<string> da2 = new List<string>();
        List<string> da3 = new List<string>();
        List<string> da4 = new List<string>();
        List<string> da5 = new List<string>();
        List<string> da6 = new List<string>();
        List<string> da7 = new List<string>();
        List<string> da8 = new List<string>();
        List<string> da9 = new List<string>();
        List<string> daa = new List<string>();
        List<string> dab = new List<string>();
        string s1, s2, s3, st1, st2, st3, sid01;              
        while (n1 <= n2)
        {
            IWebDriver driver = new ChromeDriver();         
            s1 = dt.Rows[n1]["ALLID"].ToString();
            s2 = dt.Rows[n1]["URLPATH"].ToString();
            st1 = dt.Rows[n1]["TAG1"].ToString();
            st2 = dt.Rows[n1]["TAG2"].ToString();
            sid01="3";          
            driver.Navigate().GoToUrl(s2);          
            driver.Manage().Window.Maximize();                   
            Thread.Sleep(5000);          
            s3 = driver.PageSource;
            using (StreamWriter sw = File.CreateText("1.txt"))
            {
                sw.WriteLine(s3);
            }
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        aa1.Add(line);
                    }
                }
            }
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        aa1.Add(line);
                    }
                }
            }
            //st2抓的關鍵字
            //class="Exhibition_filter_group" id=
            //產品關鍵字
            //ClassifyProduct.aspx?TripNo=
            driver.Close();
            driver.Quit();
            n1++;
        }
        n1=0;
        n2=aa1.Count-1;
        while (n1<=n2)
        {
            s1=aa1[n1];
            n3=s1.IndexOf("class="+"\""+"Exhibition_filter_group");
            if (n3>0)
            {
                s1=s1.Substring(n3);
                n4=s1.IndexOf("<p>");                
                s1=s1.Substring(n4+3);
                n4=s1.IndexOf("</p>");
                s1=s1.Substring(0,n4);
                st2=s1;
                //Console.WriteLine(s1);
            }
            n1++;
        }
    }
}
