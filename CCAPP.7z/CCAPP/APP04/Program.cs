﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Browser;
using System.Security.Cryptography;

namespace APP04;

class Program
{
    static void Main(string[] args)
    {
        MssqlR t1 = new MssqlR();
        DataTable dt;
        string url, s1, s2, st1, st2, vsql;
        int n1, n2, n3, n4, n5;
        n1 = 0;
        n2 = 0;
        n3 = 0;
        n4 = 0;
        n5 = 0;
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> aa4 = new List<string>();
        List<string> aa5 = new List<string>();
        List<string> aa6 = new List<string>();
        List<string> aa7 = new List<string>();
        url = "https://www.ystravel.com.tw/";
        IWebDriver driver = new ChromeDriver();
        driver.Navigate().GoToUrl(url);
        driver.Manage().Window.Maximize();
        Thread.Sleep(5000);
        s1 = driver.PageSource;
        using (StreamWriter sw = File.CreateText("1.txt"))
        {
            sw.WriteLine(s1);
        }
        driver.Close();
        driver.Quit();
        using (StreamReader sr = new StreamReader("1.txt"))
        {
            string line;
            while (((line = sr.ReadLine()) != null) & (n2 == 0))
            {
                if (line.IndexOf(">歐洲 <i class=") > 0)
                {
                    n1 = 1;
                }
                if (line.IndexOf(">中東杜拜 <i class=") > 0)
                {
                    n1 = 0;
                    n2 = 1;
                }
                if ((n1 == 1) & (line != ""))
                {
                    aa1.Add(line);
                }
            }
        }
        n1 = 0;
        n2 = aa1.Count - 1;
        using (StreamWriter sw = File.CreateText("2.txt"))
        {
            while (n1 <= n2)
            {
                sw.WriteLine(aa1[n1]);
                n1++;
            }
        }
        aa1.Clear();
        using (StreamReader sr = new StreamReader("2.txt"))
        {
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                if (line != "")
                {
                    s1 = line;
                    //s1.Trim();
                    aa1.Add(s1);
                }
            }
        }
        aa2.Clear();
        n1 = 0;
        n2 = aa1.Count - 1;
        while (n1 <= n2)
        {
            aa2.Add(aa1[n1]);
            n1++;
        }
        st1 = "";
        st2 = "";
        n1 = 0;
        while (n1 <= n2)
        {
            s1 = aa1[n1];
            if (s1.IndexOf(">西歐</h4>") > 0) { st1 = "西歐"; }
            if (s1.IndexOf(">南歐</h4>") > 0) { st1 = "南歐"; }
            if (s1.IndexOf(">東歐</h4>") > 0) { st1 = "東歐"; }
            if (s1.IndexOf(">北歐</h4>") > 0) { st1 = "北歐"; }
            n3 = s1.IndexOf("<a href=");
            if (n3 >= 0)
            {
                s1 = s1.Substring(n3 + 9);
                s1 = s1.Substring(0, s1.IndexOf("\""));
                if (s1 != "#")
                {
                    if (s1.IndexOf(":;") < 0)
                    {
                        s2 = aa2[n1 + 1] + aa2[n1 + 2] + aa2[n1 + 3] + aa2[n1 + 4] + aa2[n1 + 5];
                        s2 = s2.Substring(0, s2.IndexOf("</p>"));
                        n4 = s2.IndexOf(">");
                        s2 = s2.Substring(n4 + 1);
                        aa3.Add(s1);
                        aa4.Add(st1);
                        aa5.Add(s2);
                        //Console.WriteLine(s1 + "," + st1 + "," + s2);
                    }
                }
            }
            n1++;
        }
        n1=0;
        n2=aa3.Count-1;
        aa1.Clear();
        s1 = "truncate table P01V;";
        aa1.Add(s1);
        t1.RunSQL_TRAN(aa1);
        aa1.Clear();
        while (n1 <= n2)
        {
            s1 = "insert into P01V (URLPATH,ID01,TAG1,TAG2) values (";
            s1 += t1.QuotedStr(aa3[n1]) + ",";
            s1 += t1.QuotedStr("2") + ",";
            s1 += t1.QuotedStr(aa4[n1]) + ",";
            s1 += t1.QuotedStr(aa5[n1]) + ");";
            aa1.Add(s1);
            n1++;
        }
        t1.RunSQL_TRAN(aa1);
           vsql = "SELECT COUNT(*) CNT FROM P01V";
        dt = t1.RunSQL(vsql);
        Console.WriteLine(dt.Rows[0]["CNT"].ToString());
    }
}
