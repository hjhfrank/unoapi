<template>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">篩選公司:</div>
    <el-checkbox v-model="v091" label="鳳凰" />
    <el-checkbox v-model="v092" label="永信" />
    <el-checkbox v-model="v093" label="巨匠" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">出發日期起迄:</div>
    <el-date-picker v-model="v011" type="date" style="width:150px" />
    <div style="font-size:24px">～</div>
    <el-date-picker v-model="v012" type="date" style="width:150px" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">旅遊天數:</div>
    <el-input v-model="v031" style="width: 40px;text-align: left;" />
    <div style="font-size:18px">～</div>
    <el-input v-model="v032" style="width: 40px;text-align: left;" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">航空公司:</div>
    <el-checkbox v-model="v041" label="CI 中華航空" />
    <el-checkbox v-model="v042" label="BR 長榮航空" />
    <el-checkbox v-model="v043" label="EK 阿聯酋航空" />
    <el-checkbox v-model="v044" label="TK 土耳其航空 " />
    <el-checkbox v-model="v045" label="CX 國泰航空" />
    <el-checkbox v-model="v046" label="KL 荷蘭皇家航空 " />
    <el-checkbox v-model="v047" label="LH 漢莎航空" />
    <el-checkbox v-model="v048" label="SQ 新加坡航空" />
    <el-checkbox v-model="v049" label="SU 俄羅斯航空 " />
    <el-checkbox v-model="v04a" label="TG 泰國國際航空" />
    <el-checkbox v-model="v04b" label="QR 卡達航空" />
    <el-checkbox v-model="v04c" label="OM 蒙古民用航空" />
    <el-checkbox v-model="v04d" label="CA 中國國際航空" />
    <el-checkbox v-model="v04e" label="HO 吉祥航空" />
    <el-checkbox v-model="v04f" label="MU 中國東方航空 " />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">團費區間:</div>
    <el-input v-model="v021" style="width: 100px;text-align: left;" />
    <div style="font-size:18px">～</div>
    <el-input v-model="v022" style="width: 100px;text-align: left;" />
    <el-checkbox v-model="v08" label="加入篩選(請注意本項加入無法顯示鳳凰結團資料)" style="padding-left: 5px;" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">團體狀態:</div>
    <el-checkbox v-model="v061" label="報名" />
    <el-checkbox v-model="v062" label="候補" />
    <el-checkbox v-model="v063" label="即將成團" />
    <el-checkbox v-model="v064" label="已成團 " />
    <el-checkbox v-model="v065" label="保證出團" />
    <el-checkbox v-model="v066" label="結團" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">關鍵字:</div>
    <el-input v-model="v07" style="width: 200px" placeholder="關鍵字">
    </el-input>
    <el-button @click="btn3()"
      style="font-size:18px;padding-top: 8px;color:blue;border-style: none;background-color: transparent;">
      國家:
    </el-button>
    <el-input v-model="v10" style="width: 400px">
    </el-input>
  </el-row>
  <el-row>
    <div style="height:3px"></div>
    <div style="font-size:18px;padding-top: 8px;">排序:</div>
    <el-radio-group v-model="v12">
      <el-radio value="1" size="large">出發日期+產品名稱</el-radio>
      <el-radio value="2" size="large">產品名稱+出發日期</el-radio>
    </el-radio-group>
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <el-button @click="btn1()">條件搜尋+關鍵字</el-button>
    <el-button @click="btn5()">團號搜尋</el-button>
    <el-button v-if="isshow1" type="primary" @click="btn2">Excel輸出</el-button>
    <template v-if="isshow1"><span style="padding-left: 10px;padding-top: 4px;color: blue;">共{{ vrec
        }}筆</span></template>
  </el-row>
  <template v-if="isshow1">
    <div style="height:3px"></div>
    <el-table :data="srrec" style="width: 100%" id="excelo">
      <el-table-column prop="ID01" label="公司" width="60" />
      <el-table-column prop="CRTDT" label="收集日期" width="150" />
      <el-table-column prop="STDATE,WEEKOF" label="出發日" width="120">
        <template #default="scope">
          {{ scope.row.STDATE }}({{ scope.row.WEEKOF }})
        </template>
      </el-table-column>
      <el-table-column prop="SIGNSTS" label="報名" width="60" />
      <el-table-column prop="SALENO,PRODNAME,URLPATH2" label="名稱" width="550">
        <template #default="scope">
          {{ scope.row.SALENO }} <br>
          <el-button @click="btnURL(scope.row.URLPATH2)"
            style="border-style: none;background-color: transparent;padding-left: 0px;color:blue">
            {{ scope.row.PRODNAME }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="AIRLINE" label="班機" width="60" />
      <el-table-column prop="T_DAY" label="天數" width="60" />
      <el-table-column prop="SALES" label="團費" width="80" />
      <el-table-column prop="QTY" label="機位" width="60" />
    </el-table>
  </template>
  <el-dialog v-model="isdlg1" title="團號歷史查詢" width="300">
    <el-input v-model="sno" style="width: 100%" />
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dlg1btn(1)">放棄</el-button>
        <el-button type="primary" @click="dlg1btn(2)">
          確定
        </el-button>
      </div>
    </template>
  </el-dialog>
  <el-dialog v-model="isdlg2" title="Excel檔案名稱" width="300">
    <el-input v-model="dnfile" style="width: 100%" />
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dlg2btn(1)">放棄</el-button>
        <el-button type="primary" @click="dlg2btn(2)">
          確定
        </el-button>
      </div>
    </template>
  </el-dialog>
  <el-dialog v-model="isdlg3" title="查詢等待" width="300">
    <el-row>查詢中</el-row>
  </el-dialog>
  <el-dialog v-model="isdlg4" title="國家組合" width="50%" style="font-size: 14px;" align-center>
    <el-row>
      <el-radio-group style="font-size:14px;" v-model="vdg401">
        <el-radio value="1" size="large">簡稱</el-radio>
        <el-radio value="2" size="large">全稱</el-radio>
      </el-radio-group>
    </el-row>
    <div style="height:3px;"></div>
    <div style="font-size:14px;color:brown">西歐</div>
    <el-row>
      <el-checkbox v-model="vdg4001" label="英國" />
      <el-checkbox v-model="vdg4002" label="法國" />
      <el-checkbox v-model="vdg4003" label="荷蘭" />
      <el-checkbox v-model="vdg4004" label="比利時" />
      <el-checkbox v-model="vdg4005" label="盧森堡" />
      <el-checkbox v-model="vdg4006" label="摩納哥" />
      <el-checkbox v-model="vdg4007" label="愛爾蘭" />
    </el-row>
    <div style="font-size:14px;color:brown">中歐</div>
    <el-row>
      <el-checkbox v-model="vdg4008" label="德國" />
      <el-checkbox v-model="vdg4009" label="瑞士" />
      <el-checkbox v-model="vdg4010" label="列支敦斯登" />
      <el-checkbox v-model="vdg4011" label="奧地利" />
      <el-checkbox v-model="vdg4012" label="匈牙利" />
      <el-checkbox v-model="vdg4013" label="捷克" />
      <el-checkbox v-model="vdg4014" label="波蘭" />
      <el-checkbox v-model="vdg4015" label="斯洛伐克" />
      <el-checkbox v-model="vdg4016" label="克羅埃西亞" />
      <el-checkbox v-model="vdg4017" label="斯洛維尼亞" />
    </el-row>
    <div style="font-size:14px;color:brown">南歐</div>
    <el-row>
      <el-checkbox v-model="vdg4018" label="義大利" />
      <el-checkbox v-model="vdg4019" label="希臘" />
      <el-checkbox v-model="vdg4020" label="葡萄牙 " />
      <el-checkbox v-model="vdg4021" label="西班牙 " />
      <el-checkbox v-model="vdg4022" label="馬爾他" />
      <el-checkbox v-model="vdg4023" label="直布羅陀" />
      <el-checkbox v-model="vdg4024" label="安道爾 " />
      <el-checkbox v-model="vdg4025" label="聖馬利諾" />
    </el-row>
    <div style="font-size:14px;color:brown">北歐</div>
    <el-row>
      <el-checkbox v-model="vdg4026" label="瑞典" />
      <el-checkbox v-model="vdg4027" label="丹麥" />
      <el-checkbox v-model="vdg4028" label="挪威" />
      <el-checkbox v-model="vdg4029" label="芬蘭 " />
      <el-checkbox v-model="vdg4030" label="冰島 " />
    </el-row>
    <div style="font-size:14px;color:brown">東歐</div>
    <el-row>
      <el-checkbox v-model="vdg4031" label="俄羅斯" />
      <el-checkbox v-model="vdg4032" label="烏克蘭" />
      <el-checkbox v-model="vdg4033" label="白俄羅斯" />
      <el-checkbox v-model="vdg4034" label="蒙特內哥羅" />
      <el-checkbox v-model="vdg4035" label="阿爾巴尼亞" />
      <el-checkbox v-model="vdg4036" label="塞爾維亞" />
      <el-checkbox v-model="vdg4037" label="科索沃" />
      <el-checkbox v-model="vdg4038" label="北馬其頓" />
      <el-checkbox v-model="vdg4039" label="保加利亞" />
      <el-checkbox v-model="vdg4040" label="羅馬尼亞" />
      <el-checkbox v-model="vdg4041" label="立陶宛" />
      <el-checkbox v-model="vdg4042" label="拉脫維亞" />
      <el-checkbox v-model="vdg4043" label="愛沙尼亞 " />
      <el-checkbox v-model="vdg4044" label="摩爾多瓦" />
    </el-row>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="btn31(1)">放棄</el-button>
        <el-button type="primary" @click="btn31(2)">
          確定
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script>
import { defineComponent, ref } from 'vue';
import axios from 'axios';
import dayjs from 'dayjs';
import * as XLSX from "xlsx";
//ms sql對於欄位大小寫不敏感,但是postgresql,mysql非常敏感,以後web app開欄位小寫

export default defineComponent({
  name: "HelloWorld",
  data() {
    return {
      v011: dayjs(),
      v012: dayjs(),
      v021: '10000',
      v022: '200000',
      v031: '7',
      v032: '14',
      //v041: 'BR',
      //v042: 'TK',
      v041: false,
      v042: false,
      v043: false,
      v044: false,
      v045: false,
      v046: false,
      v047: false,
      v048: false,
      v049: false,
      v04a: false,
      v04b: false,
      v04c: false,
      v04d: false,
      v04e: false,
      v04f: false,
      v051: '日',
      v052: '六',
      v061: false,
      v062: false,
      v063: false,
      v064: false,
      v065: false,
      v066: false,
      v07: '',
      v08: true,
      v091: true,
      v092: true,
      v093: true,
      v10: '',
      v11: '',
      v12: '1',
      srrec: [],
      srrec1: [],
      isshow1: false,
      sno: '',
      isdlg1: false,
      isdlg2: false,
      isdlg3: false,
      dnfile: dayjs().format('YYYYMMDD'),
      nselbtn: 0,
      vrec: 0,
      isdlg4: false,
      vdg401: '1',
      vdg4001: false,
      vdg4002: false,
      vdg4003: false,
      vdg4004: false,
      vdg4005: false,
      vdg4006: false,
      vdg4007: false,
      vdg4008: false,
      vdg4009: false,
      vdg4010: false,
      vdg4011: false,
      vdg4012: false,
      vdg4013: false,
      vdg4014: false,
      vdg4015: false,
      vdg4016: false,
      vdg4017: false,
      vdg4018: false,
      vdg4019: false,
      vdg4020: false,
      vdg4021: false,
      vdg4022: false,
      vdg4023: false,
      vdg4024: false,
      vdg4025: false,
      vdg4026: false,
      vdg4027: false,
      vdg4028: false,
      vdg4029: false,
      vdg4030: false,
      vdg4031: false,
      vdg4032: false,
      vdg4033: false,
      vdg4034: false,
      vdg4035: false,
      vdg4036: false,
      vdg4037: false,
      vdg4038: false,
      vdg4039: false,
      vdg4040: false,
      vdg4041: false,
      vdg4042: false,
      vdg4043: false,
      vdg4044: false,
      vdg4list: [],
    };
  },
  //巨匠滿團仍有人數,滿團視為結團
  //可報名->報名
  //滿團可候補,滿候補->候補
  //永信
  //截止->結團
  //鳳凰先改
  methods: {
    btnURL(s1) {
      //let s1;
      //console.log(e);
      //s1 = e.target.innerText;
      window.open(s1, '_blank');
    },
    async btn1() {
      this.isshow1 = false;
      this.isdlg3 = true;
      let param = {
        'v011': dayjs(this.v011).format('YYYY-MM-DD'),
        'v012': dayjs(this.v012).format('YYYY-MM-DD'),
        'v021': this.v021,
        'v022': this.v022,
        'v031': this.v031,
        'v032': this.v032,
        'v041': this.v041,
        'v042': this.v042,
        'v043': this.v043,
        'v044': this.v044,
        'v045': this.v045,
        'v046': this.v046,
        'v047': this.v047,
        'v048': this.v048,
        'v049': this.v049,
        'v04a': this.v04a,
        'v04b': this.v04b,
        'v04c': this.v04c,
        'v04d': this.v04d,
        'v04e': this.v04e,
        'v04f': this.v04f,
        'v051': this.v051,
        'v052': this.v052,
        'v061': this.v061,
        'v062': this.v062,
        'v063': this.v063,
        'v064': this.v064,
        'v065': this.v065,
        'v066': this.v066,
        'v07': this.v07,
        'v08': this.v08,
        'v091': this.v091,
        'v092': this.v092,
        'v093': this.v093,
        'v10': this.v10,
        'v11': this.v11,
        'v12': this.v12,
      }
      this.ex = await this.btn11(param);
    },
    btn11(param) {
      return new Promise((res, rej) => {
        axios({
          method: 'POST',
          url: "http://localhost:5055/listvvv",
          //url: "http://192.168.1.189:3000/listvvv",
          //url: "http://192.168.1.58:3000/listvvv",
          data: param
        }).then(async (res) => {
          this.srrec = res.data.dt;
          //console.log(res.data.dt);
          //console.log(this.srrec);
          if (this.srrec.length > 0) {
            this.vrec = this.srrec.length;
            this.isshow1 = true;
          }
          else { alert('搜尋不到資料') }
          //this.isshow1 = true;
          this.isdlg3 = false;
        }).catch((error) => {
          //alert('網路出現錯誤');
          alert(error);
        });
      });
    },
    async dlg1btn(nn) {
      this.isshow1 = false;
      //this.isdlg3 = true;
      if (nn == 2) {
        let param = { 'sno': this.sno };
        this.isdlg3 = true;
        this.ex = await this.dlg1btn1(param);
      }
      this.isdlg1 = false;
    },
    dlg1btn1(param) {
      return new Promise((res, rej) => {
        axios({
          method: 'POST',
          url: "http://localhost:5055/listvvv2",
          //url: "http://192.168.1.189:3000/listvvv2",                           
          //url: "http://192.168.1.58:3000/listvvv2", 
          data: param
        }).then(async (res) => {
          this.srrec = res.data.dt;
          //抓到postgresql原因了,欄位全部需要小寫
          this.isdlg1 = false;
          this.isdlg3 = false;
          if (this.srrec.length > 0) {
            this.isshow1 = true;
            this.vrec = this.srrec.length;
          }
          else { alert('搜尋不到資料') }
          //this.isdlg1 = false;
          //this.isdlg3 = false;
        }).catch((error) => {
          alert('網路出現錯誤');
        });
      });
    },
    dlg2btn(nn) {
      if (nn == 2) {
        if (this.dnfile.indexOf('.') < 0) {
          this.dnfile = this.dnfile + '.xlsx';
        }
        this.btn21();
      }
      this.isdlg2 = false;
    },
    btn2() {
      this.isdlg2 = true;
    },
    btn21() {
      //我直接加表頭
      let n1, n2;
      let a1 = [];
      let aa1 = [];
      let j1 = {};
      //ID01,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,SIGNSTS,REM,SALENO,CRTDT,ALLID,URLPATH2,URLPATH1           
      //aa1 = ["公司", "收集日期", "出發日", "報名", "產品名稱", "班機", "天數", "團費", "機位", "產品網址", "查詢網址"];
      aa1 = ["公司", "收集日期", "出發日", "報名", "產品名稱", "班機", "天數", "團費", "機位", "產品網址", "查詢網址", "TAG1", "TAG2"];
      a1.push(aa1);
      n1 = 0;
      n2 = this.srrec.length - 1;
      while (n1 <= n2) {
        j1 = this.srrec[n1];
        //aa1 = [j1["ID01"], j1["CRTDT"], j1["STDATE"] + "(" + j1["WEEKOF"] + ")", j1["SIGNSTS"], j1["SALENO"] + " " + j1["PRODNAME"], j1["AIRLINE"], j1["T_DAY"], j1["SALES"], j1["QTY"], j1["URLPATH2"], j1["URLPATH1"]];
        aa1 = [j1["ID01"], j1["CRTDT"], j1["STDATE"] + "(" + j1["WEEKOF"] + ")", j1["SIGNSTS"], j1["SALENO"] + " " + j1["PRODNAME"], j1["AIRLINE"], j1["T_DAY"], j1["SALES"], j1["QTY"], j1["URLPATH2"], j1["URLPATH1"], j1["TAG1"], j1["TAG2"], j1["ALLID"]];
        a1.push(aa1)
        n1++;
      }
      const workbook = XLSX.utils.book_new();
      //const worksheet = XLSX.utils.json_to_sheet(this.srrec);
      const worksheet = XLSX.utils.aoa_to_sheet(a1);
      let wscols = [
        { wch: 5 },
        { wch: 16 },
        { wch: 12 },
        { wch: 10 },
        { wch: 60 },
        { wch: 8 },
        { wch: 8 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
      ];
      worksheet['!cols'] = wscols;
      XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
      this.saveExcelFile(excelBuffer, this.dnfile);
    },
    //這個要修,有空
    saveExcelFile(buffer, filename) {
      const data = new Blob([buffer], {
        type: "application/octet-stream",
      });
      const url = URL.createObjectURL(data);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },
    btn3() {
      this.isdlg4 = true;
      this.vdg401 = "1";
      this.vdg4001 = false;
      this.vdg4002 = false;
      this.vdg4003 = false;
      this.vdg4004 = false;
      this.vdg4005 = false;
      this.vdg4006 = false;
      this.vdg4007 = false;
      this.vdg4008 = false;
      this.vdg4009 = false;
      this.vdg4010 = false;
      this.vdg4011 = false;
      this.vdg4012 = false;
      this.vdg4013 = false;
      this.vdg4014 = false;
      this.vdg4015 = false;
      this.vdg4016 = false;
      this.vdg4017 = false;
      this.vdg4018 = false;
      this.vdg4019 = false;
      this.vdg4020 = false;
      this.vdg4021 = false;
      this.vdg4022 = false;
      this.vdg4023 = false;
      this.vdg4024 = false;
      this.vdg4025 = false;
      this.vdg4026 = false;
      this.vdg4027 = false;
      this.vdg4028 = false;
      this.vdg4029 = false;
      this.vdg4030 = false;
      this.vdg4031 = false;
      this.vdg4032 = false;
      this.vdg4033 = false;
      this.vdg4034 = false;
      this.vdg4035 = false;
      this.vdg4036 = false;
      this.vdg4037 = false;
      this.vdg4038 = false;
      this.vdg4039 = false;
      this.vdg4040 = false;
      this.vdg4041 = false;
      this.vdg4042 = false;
      this.vdg4043 = false;
      this.vdg4044 = false;
    },
    btn31(ns) {
      let s1 = "";
      let s2 = "";
      let aa1 = [];
      let n1 = 0;
      let n2 = 0;
      if (ns == 2) {
        if (this.vdg4001) { aa1.push(1); }
        if (this.vdg4002) { aa1.push(2); }
        if (this.vdg4003) { aa1.push(3); }
        if (this.vdg4004) { aa1.push(4); }
        if (this.vdg4005) { aa1.push(5); }
        if (this.vdg4006) { aa1.push(6); }
        if (this.vdg4007) { aa1.push(7); }
        if (this.vdg4008) { aa1.push(8); }
        if (this.vdg4009) { aa1.push(9); }
        if (this.vdg4010) { aa1.push(10); }
        if (this.vdg4011) { aa1.push(11); }
        if (this.vdg4012) { aa1.push(12); }
        if (this.vdg4013) { aa1.push(13); }
        if (this.vdg4014) { aa1.push(14); }
        if (this.vdg4015) { aa1.push(15); }
        if (this.vdg4016) { aa1.push(16); }
        if (this.vdg4017) { aa1.push(17); }
        if (this.vdg4018) { aa1.push(18); }
        if (this.vdg4019) { aa1.push(19); }
        if (this.vdg4020) { aa1.push(20); }
        if (this.vdg4021) { aa1.push(21); }
        if (this.vdg4022) { aa1.push(22); }
        if (this.vdg4023) { aa1.push(23); }
        if (this.vdg4024) { aa1.push(24); }
        if (this.vdg4025) { aa1.push(25); }
        if (this.vdg4026) { aa1.push(26); }
        if (this.vdg4027) { aa1.push(27); }
        if (this.vdg4028) { aa1.push(28); }
        if (this.vdg4029) { aa1.push(29); }
        if (this.vdg4030) { aa1.push(30); }
        if (this.vdg4031) { aa1.push(31); }
        if (this.vdg4032) { aa1.push(32); }
        if (this.vdg4033) { aa1.push(33); }
        if (this.vdg4034) { aa1.push(34); }
        if (this.vdg4035) { aa1.push(35); }
        if (this.vdg4036) { aa1.push(36); }
        if (this.vdg4037) { aa1.push(37); }
        if (this.vdg4038) { aa1.push(38); }
        if (this.vdg4039) { aa1.push(39); }
        if (this.vdg4040) { aa1.push(40); }
        if (this.vdg4041) { aa1.push(41); }
        if (this.vdg4042) { aa1.push(42); }
        if (this.vdg4043) { aa1.push(43); }
        if (this.vdg4044) { aa1.push(44); }
        n2 = aa1.length - 1;
        while (n1 <= n2) {
          if (this.vdg401 == "1") {
            s2 = this.vdg4list[aa1[n1] - 1];
            s2 = s2.substring(0, 1);
            s1 = s1 + s2 + ",";
          }
          else {
            s2 = this.vdg4list[aa1[n1] - 1];
            s1 = s1 + s2 + ",";
          }
          n1++;
        }
        if (s1 != '') {
          s1 = s1.substring(0, s1.length - 1);
        }
        //if (this.v10 != '') {
        //  this.v10 = ',' + s1;
        //}
        //else {
        this.v10 = s1;
        //}
      }
      this.isdlg4 = false;
    },
    btn5() {
      //EUF082611TK24A
      this.isshow1 = false;
      this.isdlg1 = true;
    }
  },
  created() {
    let v1 = dayjs();
    let v2 = v1.add(1, 'month');
    this.v011 = v1;
    this.v012 = v2;
    this.vdg4list.push("英國");
    this.vdg4list.push("法國");
    this.vdg4list.push("荷蘭");
    this.vdg4list.push("比利時");
    this.vdg4list.push("盧森堡");
    this.vdg4list.push("摩納哥");
    this.vdg4list.push("愛爾蘭");
    this.vdg4list.push("德國");
    this.vdg4list.push("瑞士");
    this.vdg4list.push("列支敦斯登");
    this.vdg4list.push("奧地利");
    this.vdg4list.push("匈牙利");
    this.vdg4list.push("捷克");
    this.vdg4list.push("波蘭");
    this.vdg4list.push("斯洛伐克");
    this.vdg4list.push("克羅埃西亞");
    this.vdg4list.push("斯洛維尼亞");
    this.vdg4list.push("義大利");
    this.vdg4list.push("希臘");
    this.vdg4list.push("葡萄牙");
    this.vdg4list.push("西班牙");
    this.vdg4list.push("馬爾他");
    this.vdg4list.push("直布羅陀");
    this.vdg4list.push("安道爾");
    this.vdg4list.push("聖馬利諾");
    this.vdg4list.push("瑞典");
    this.vdg4list.push("丹麥");
    this.vdg4list.push("挪威");
    this.vdg4list.push("芬蘭");
    this.vdg4list.push("冰島");
    this.vdg4list.push("俄羅斯");
    this.vdg4list.push("烏克蘭");
    this.vdg4list.push("白俄羅斯");
    this.vdg4list.push("蒙特內哥羅");
    this.vdg4list.push("阿爾巴尼亞");
    this.vdg4list.push("塞爾維亞");
    this.vdg4list.push("科索沃");
    this.vdg4list.push("北馬其頓");
    this.vdg4list.push("保加利亞");
    this.vdg4list.push("羅馬尼亞");
    this.vdg4list.push("立陶宛");
    this.vdg4list.push("拉脫維亞");
    this.vdg4list.push("愛沙尼亞");
    this.vdg4list.push("摩爾多瓦");
  },
});

/*
 <el-table :data="srrec" style="width: 100%" id="excelo">
      <el-table-column prop="ID01" label="公司" width="60" />
      <el-table-column prop="CRTDT" label="收集日期" width="150" />
      <el-table-column prop="STDATE,WEEKOF" label="出發日" width="120">
        <template #default="scope">
          {{ scope.row.STDATE }}({{ scope.row.WEEKOF }})
        </template>
      </el-table-column>
      <el-table-column prop="SIGNSTS" label="報名" width="60" />
      <el-table-column prop="SALENO,PRODNAME,URLPATH2" label="名稱" width="550">
        <template #default="scope">
          {{ scope.row.SALENO }} <br>
          <el-button @click="btnURL(scope.row.URLPATH2)"
            style="border-style: none;background-color: transparent;padding-left: 0px;color:blue">
            {{ scope.row.PRODNAME }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="AIRLINE" label="班機" width="60" />
      <el-table-column prop="T_DAY" label="天數" width="60" />
      <el-table-column prop="SALES" label="團費" width="80" />
      <el-table-column prop="QTY" label="機位" width="60" />
    </el-table>
     <el-table :data="srrec" style="width: 100%" id="excelo">
      <el-table-column prop="id01" label="公司" width="60" />
      <el-table-column prop="crtdt" label="收集日期" width="150" />
      <el-table-column prop="stdate,weekof" label="出發日" width="120">
        <template #default="scope">
          {{ scope.row.stdate }}({{ scope.row.weekof }})
        </template>
      </el-table-column>
      <el-table-column prop="signsts" label="報名" width="60" />
      <el-table-column prop="saleno,prodname,urlpath2" label="名稱" width="550">
        <template #default="scope">
          {{ scope.row.SALENO }} <br>
          <el-button @click="btnURL(scope.row.urlpath2)"
            style="border-style: none;background-color: transparent;padding-left: 0px;color:blue">
            {{ scope.row.prodname }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="airline" label="班機" width="60" />
      <el-table-column prop="t_day" label="天數" width="60" />
      <el-table-column prop="sales" label="團費" width="80" />
      <el-table-column prop="qty" label="機位" width="60" />
    </el-table>
*/

</script>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
