using System;
using System.Data;
using Newtonsoft.Json;
using Npgsql;

namespace appsql
{
    class PssqlR
    {
        private string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=hjhjack;Database=testdb";

        public string QuotedStr(string S)
        {
            string vResult;
            vResult = S;
            for (int i = vResult.Length - 1; i >= 0; i--)
            {
                if (vResult[i].Equals('\''))
                {
                    vResult = vResult.Insert(i, "\'");
                }
            }
            vResult = "'" + vResult + "'";
            return vResult;
        }

        public DataTable RunSQL(string sSQL)
        {
            NpgsqlConnection ct = new NpgsqlConnection(connectionString);
            ct.Open();
            NpgsqlCommand command = new NpgsqlCommand(sSQL, ct);
            NpgsqlDataReader reader = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);
            ct.Close();
            return dt;
        }

        public int RunSQLc(string sSQL)
        {
            int i;
            NpgsqlConnection ct = new NpgsqlConnection(connectionString);
            ct.Open();
            NpgsqlCommand command = new NpgsqlCommand(sSQL, ct);
            i = command.ExecuteNonQuery();
            ct.Close();
            return i;
        }

        public string RunSQL_TRAN(List<string> sSQL)
        {
            string msg = "ok";
            NpgsqlConnection ct = new NpgsqlConnection(connectionString);
            ct.Open();
            NpgsqlCommand sqlWrite = ct.CreateCommand();
            NpgsqlTransaction trans = ct.BeginTransaction();
            sqlWrite.Transaction = trans;
            try
            {
                foreach (string s1 in sSQL)
                {
                    sqlWrite.CommandText = s1;
                    sqlWrite.ExecuteNonQuery();
                }
                trans.Commit();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                msg = "ng";
            }
            finally
            {
                ct.Close();
                sqlWrite.Dispose();
                ct.Dispose();
                trans.Dispose();
            }
            return msg;
        }
    }
}
