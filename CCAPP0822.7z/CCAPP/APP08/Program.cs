﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Browser;
using System.Security.Cryptography;


namespace APP08;

class Program
{
    static void Main(string[] args)
    {
        string url,s1;
        url = "https://www.travel.com.tw/";
        IWebDriver driver = new ChromeDriver();
        driver.Navigate().GoToUrl(url);
        driver.Manage().Window.Maximize();
        Thread.Sleep(5000);
        s1 = driver.PageSource;
        using (StreamWriter sw = File.CreateText("1.txt"))
        {
            sw.WriteLine(s1);
        }
        driver.Close();
        driver.Quit();
    }
}
