﻿using OpenQA.Selenium;
//using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Browser;
using System.Security.Cryptography;

namespace APP06;

class Program
{
    static void Main(string[] args)
    {
        MssqlR t1 = new MssqlR();
        DataTable dt;
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> aa4 = new List<string>();
        int n1, n2;
        string s1;
        aa1.Add("https://www.artisan.com.tw/exh/Exhibition.aspx?area_no=1");
        aa1.Add("https://www.artisan.com.tw/exh/Exhibition.aspx?area_no=2");
        aa1.Add("https://www.artisan.com.tw/exh/Exhibition.aspx?area_no=5");
        aa1.Add("https://www.artisan.com.tw/exh/Exhibition.aspx?area_no=6");
        aa2.Add("中西歐");
        aa2.Add("東歐");
        aa2.Add("南歐");
        aa2.Add("北歐");
        n1 = 0;
        n2 = aa1.Count - 1;
        while (n1 <= n2)
        {
            s1 = "insert into P01V (URLPATH,ID01,TAG1,TAG2) values (";
            s1 += t1.QuotedStr(aa1[n1]) + ",";
            s1 += t1.QuotedStr("3") + ",";
            s1 += t1.QuotedStr(aa2[n1]) + ",";
            s1 += t1.QuotedStr("") + ");";
            aa3.Add(s1);
            n1++;
        }
        s1 = "truncate table P01V;";
        aa4.Add(s1);
        t1.RunSQL_TRAN(aa4);
        t1.RunSQL_TRAN(aa3);
        s1 = "SELECT COUNT(*) CNT FROM P01V";
        dt = t1.RunSQL(s1);
        Console.WriteLine(dt.Rows[0]["CNT"].ToString());
    }
}
