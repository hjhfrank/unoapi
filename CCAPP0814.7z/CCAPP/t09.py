from selenium import webdriver
from selenium.webdriver.common.by import By
import requests
import io

def findss(s1,s2):
    n1=0
    try:
       n1=s1.index(s2)    
    except:
       n1=-1
    #print(n1)   
    return n1      
#巨匠寫的亂,要注意
#https://www.artisan.com.tw/ClassifyProduct.aspx?TripNo=T20231127000003
url="https://www.ystravel.com.tw/products/group/mold/FRA13CIX3A"
url="https://www.ystravel.com.tw/austrian-czech"
url="https://www.artisan.com.tw/exh/ExhMini.aspx?area_no=1&no=3"
url="https://www.travel.com.tw/HALL/Index/EU"
url="https://www.ystravel.com.tw/products/group/mold/LON09CIE103W"
url="https://www.ystravel.com.tw/products/group/search?selFrom=selH&regm_cd=0001&sdate=&edate=&kwd="
url="https://www.ystravel.com.tw/austrian-czech"
url="https://www.artisan.com.tw/exh/ExhMini.aspx?area_no=1&amp;no=169"
urllist=[]
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=1")
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=2")
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=5")
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=6")


driver=webdriver.Firefox()   
#driver.get("https://www.ystravel.com.tw/products/group/mold/rom10cii103p?sacct_no=86887029") 
#driver.get(urllist[0])
driver.get("https://www.artisan.com.tw/ClassifyProduct.aspx?TripNo=T20231227000003") 
s2 = driver.page_source
s1="t9"+'.txt'
with open(s1, "w",encoding="utf-8") as file:
    file.write(s2)
driver.quit()
 