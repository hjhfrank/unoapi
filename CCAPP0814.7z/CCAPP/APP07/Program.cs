﻿using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;


namespace APP07;

class Program
{
    static void Main(string[] args)
    {
        MssqlR t1 = new MssqlR();
        List<string> aa1 = new List<string>();
        DataTable dt;
        string vsql, s1, s2, sallid,s3,s4,s5,s6;
        string[] sa1;
        int n1;
        //永信的情況較複雜,團號有問題 ?以及https
        vsql = "select ALLID,AIRLINE,STDATE,T_DAY,SALES,ISALES,QTY,IQTY,IDAY,SALENO,ID01,URLPATH1 FROM P02V WHERE ID01='巨匠'";
        //vsql = "select ALLID,AIRLINE,STDATE,T_DAY,SALES,ISALES,QTY,IQTY,IDAY,URLPATH1,SALENO FROM P02V WHERE ID01='永信'";
        s1 = "";
        s2 = "";
        s3="";
        s4="";
        s5="";
        s6="";
        sallid = "";
        sa1 = [];
        dt = t1.RunSQL(vsql);
        n1 = 0;
        foreach (DataRow r1 in dt.Rows)
        {
            sallid = r1["ALLID"].ToString();
            s1 = r1["STDATE"].ToString();
            s2 = r1["STDATE"].ToString();
            sa1=s2.Split("-");
            s2=sa1[0]+"/"+sa1[1]+"/"+sa1[2];
            s3 = r1["SALENO"].ToString();
            s4=r1["AIRLINE"].ToString();
            //"https://www.artisan.com.tw/TripIntroduction.aspx?TripNo="T20231101000002&Date=2024/08/14&type=EK
            s5="https://www.artisan.com.tw/TripIntroduction.aspx?TripNo="+s3+"&Date="+s2+"&type="+s4+"&tc=y";
            Console.WriteLine(s5); 
            //s4=s3;
            //n1=s3.IndexOf("https:");
            //n1=s3.IndexOf("?");
            //if (n1>0)
            //{
            //   s3=s3.Substring(0,n1);
            //}
            //if (n1>0)
            //{
            //  Console.WriteLine(s3+" "+s4+" "+n1.ToString());
            //}


            //s2=s2.Replace("/mold/","/detail/");
            //n1=s2.IndexOf("/detail");
            //s2=s2.Substring(0,n1+8);           

            //Console.WriteLine(s2+" "+s3);
            


           
            aa1.Clear();
            aa1.Add("UPDATE P02V SET URLPATH2='"+s5+"' where ALLID=" + sallid);

            //s2 = r1["SALES"].ToString();



            //s1 = r1["STDATE"].ToString();
            //s2 = r1["SALES"].ToString();

            //sa1 = s1.Split('.');
            //if (sa1.Length == 3)
            //{
            //    s1 = sa1[0] + "-" + sa1[1] + "-" + sa1[2];
            //}
            //if (s2.IndexOf(",") > 0)
            //{
            //    sa1 = s2.Split(",");
            //    if (sa1.Length > 0)
            //    {
            //        s2 = sa1[0] + sa1[1];
            //    }
            //}
            //if (s2 == "") { s2 = "0"; }
            //aa1.Clear();
            //aa1.Add("UPDATE P02V SET STDATE='" + s1 + "',ISALES=" + s2 + " where ALLID=" + sallid);
            /*
            //aa1.Add("UPDATE P02V SET STDATE='" + s1 + "' where ALLID=" + sallid);
            //這段很奇怪,我直接用app03航空公司,居然有問題
            s1 = r1["AIRLINE"].ToString();
            if (s1 == "土耳其航空") { s1 = "TK"; }
            if (s1 == "中華航空") { s1 = "CI"; }
            if (s1 == "卡達航空") { s1 = "QR"; }
            if (s1 == "長榮航空") { s1 = "BR"; }
            if (s1 == "阿聯酋航空") { s1 = "EK"; }
            if (s1 == "泰國航空") { s1 = "TG"; }
            if (s1 == "國泰航空") { s1 = "CX"; }
            if (s1 == "新加坡航空") { s1 = "SQ"; }
            Console.WriteLine(s1);
            aa1.Clear();
            aa1.Add("UPDATE P02V SET AIRLINE='" + s1 + "' where ALLID=" + sallid);
            
            
            int n1, n2;
            n1 = 0;
            n2 = 0;
            s1 = r1["T_DAY"].ToString();
            s2 = r1["QTY"].ToString();
            try
            {
                n1 = Int32.Parse(s1);
            }
            catch (FormatException e)
            {
                n1 = 0;
            }
            try
            {
                n2 = Int32.Parse(s2);
            }
            catch (FormatException e)
            {
                n2 = 0;
            }
            s1=n1.ToString();
            s2=n2.ToString();
            aa1.Clear();
            aa1.Add("UPDATE P02V SET IQTY=" + s2 + ",IDAY="+s1+ " where ALLID=" + sallid);
            */
            s1 = t1.RunSQL_TRAN(aa1);
            if (s1 == "ok")
            {
                Console.WriteLine(s1);
            }
            else
            {
                Console.WriteLine(s1 + " " + sallid);
            }
            

        }
    }
}
