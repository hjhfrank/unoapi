using System;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Network;

/*
  RunSQLc針對1條語句，應該是隱含交易功能，不建議使用
  RunSQL_TRAN明確交易處理
*/

namespace apmssql
{
  class MssqlR
  {
    private string connectionString = "Data Source=.\\sqlexpress; Initial Catalog=UNO;Persist Security Info=False;User ID=sa;Password=1234;encrypt=false;";

    public string RunData(string surl, string surl2, string st1, string st2)
    {

      string s1, s2, s3, vsql;
      int n1, n2, n3, n4, n5, n6, nl, nday,nk1,nk2;
      nday = 0;
      nk1=0;
      nk2=0;
      string[] sa1, sa2,sa3;
      List<string> aa1 = new List<string>();
      List<string> aa2 = new List<string>();
      List<string> aa3 = new List<string>();
      List<string> aa4 = new List<string>();
      List<string> da1 = new List<string>();
      List<string> da2 = new List<string>();
      List<string> da3 = new List<string>();
      List<string> da4 = new List<string>();
      List<string> da5 = new List<string>();
      List<string> da6 = new List<string>();
      List<string> da7 = new List<string>();
      List<string> da8 = new List<string>();
      List<string> da9 = new List<string>();
      List<string> daa = new List<string>();
      IWebDriver driver = new ChromeDriver();

      driver.Navigate().GoToUrl(surl2);
      driver.Manage().Window.Maximize();
      Thread.Sleep(5000);
      s3 = driver.PageSource;
      using (StreamWriter sw = File.CreateText("1.txt"))
      {
        sw.WriteLine(s3);
      }
      using (StreamReader sr = new StreamReader("1.txt"))
      {
        string line;
        while ((line = sr.ReadLine()) != null)
        {
          if (line != "")
          {
            aa3.Add(line);
          }
        }
      }
      driver.Close();
      driver.Quit();
      n3 = 0;
      n4 = aa3.Count - 1;
      nl = 0;
      while (n3 <= n4)
      {
        s1 = aa3[n3];
        n5 = s1.IndexOf("GridView1");
        if (n5 > 0) { nl = 1; }
        n6 = s1.IndexOf("<!-- footer -->");
        if (n6 >= 0) { nl = 0; }
        if (nl == 1) { aa4.Add(s1); }
        n3++;
      }
      aa3.Clear();
      n3 = 0;
      n4 = aa4.Count - 1;
      while (n3 <= n4)
      {
        aa3.Add(aa4[n3]);
        n3++;
      }
      n3 = 0;
      n4 = aa3.Count - 1;
      s1 = "";
      while (n3 <= n4)
      {
        s1 = s1 + aa3[n3];
        n3++;
      }
      sa1 = [];
      sa1 = s1.Split("<div class=" + "\"" + "table-content-tool" + "\"" + ">");
      n3 = 1;
      n4 = sa1.Length - 1;
      while (n3 <= n4)
      {
        s1 = sa1[n3];
        s1.Trim();
        n5 = s1.IndexOf("<span class=" + "\"" + "Syear" + "\"" + ">");
        s1 = s1.Substring(n5 + 20);
        n5 = s1.IndexOf("GridView1_hlTripName_");
        s3 = s1.Substring(n5 + 40);
        s1 = s1.Substring(0, 100) + s1.Substring(n5 + 40);
        s2 = s1.Substring(97, 1);
        s1 = s3;
        n5 = s1.IndexOf("Date=");
        s1 = s1.Substring(n5 + 5);
        s3 = s1.Substring(0, 10);
        s1 = s1.Substring(10);
        da1.Add(s2);
        sa2 = s3.Split('/');
        s3 = sa2[0] + "-" + sa2[1] + "-" + sa2[2];
        //Console.WriteLine(s3);
        da2.Add(s3);
        n5 = s1.IndexOf("<h3>");
        s1 = s1.Substring(n5 + 4);
        n5 = s1.IndexOf("</h3>");
        s2 = s1.Substring(0, n5);
        da3.Add(s2);
        s1 = s1.Substring(n5 + 3);
        n5 = s1.IndexOf("<div class=" + "\"" + "plant" + "\"" + ">");
        s1 = s1.Substring(n5);
        s2 = s1.Substring(0, 40);
        n5 = s2.IndexOf(">");
        s2 = s2.Substring(n5 + 1);
        n5 = s2.IndexOf("</div>");
        s2 = s2.Substring(0, n5);

        da4.Add(s2);
        n5 = s1.IndexOf("<div class=" + "\"" + "seat" + "\"" + ">");
        s1 = s1.Substring(n5);
        s2 = s1.Substring(0, 40);
        n5 = s2.IndexOf(">");
        s2 = s2.Substring(n5 + 1);
        n5 = s2.IndexOf("</div>");
        s2 = s2.Substring(0, n5);
        da5.Add(s2);
        n5 = s1.IndexOf("<div class=" + "\"" + "status");
        s1 = s1.Substring(n5);
        s2 = s1.Substring(0, 40);
        n5 = s2.IndexOf(">");
        s2 = s2.Substring(n5 + 1);
        n5 = s2.IndexOf("</div>");
        s2 = s2.Substring(0, n5);
        if (s2 == "滿團") { s2 = "結團"; }
        if (s2 == "可報名") { s2 = "報名"; }
        if (s2 == "滿團可候補") { s2 = "候補"; }
        if (s2 == "滿候補") { s2 = "候補"; }
        da6.Add(s2);

        n5 = s1.IndexOf("class=" + "\"" + "price-client");
        if (n5 < 0)
        {
          da7.Add("0");
          da8.Add(st2);
        }
        else
        {
          s1 = s1.Substring(n5);
          s2 = s1.Substring(0, 40);
          n5 = s2.IndexOf(">");
          s2 = s2.Substring(n5 + 1);
          n5 = s2.IndexOf("</span>");
          s2 = s2.Substring(0, n5);
          da7.Add(s2);
          da8.Add(st2);
        }
        s1 = sa1[n3];
        s1.Trim();
        n5 = s1.IndexOf("GridView1_hlTripName_");
        s2 = s1.Substring(n5, n5 + 120);
        n5 = s2.IndexOf("href");
        s2 = s2.Substring(n5 + 6);
        //sa1=s2.Split("\"");
        n5 = s2.IndexOf("\"");
        if (n5 > 0)
        {
          s2 = s2.Substring(0, n5);
        }
        Console.WriteLine(s2);
        sa3=s2.Split("amp;");
        nk1=0;
        nk2=sa3.Length-1;
        s2="";
        while (nk1<=nk2) {
          s2=s2+sa3[nk1];
          nk1++;
        }
        da9.Add(s2);
        s2="https://www.artisan.com.tw/"+s2;
        //Console.WriteLine(s2);
        daa.Add(s2);
        n3++;
      }
      aa4.Clear();
      n1 = 0;
      n2 = da1.Count - 1;
      /*
      Console.WriteLine(da1.Count.ToString());
      Console.WriteLine(da2.Count.ToString());
      Console.WriteLine(da3.Count.ToString());
      Console.WriteLine(da4.Count.ToString());
      Console.WriteLine(da5.Count.ToString());
      Console.WriteLine(da6.Count.ToString());
      Console.WriteLine(da7.Count.ToString());
      Console.WriteLine(da8.Count.ToString());
      Console.WriteLine(da9.Count.ToString());
      Console.WriteLine(daa.Count.ToString());
      */
      aa1.Clear();
      while (n1 <= n2)
      {
        vsql = "insert into P02V (URLPATH,URLPATH1,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,";
        vsql = vsql + "SIGNSTS,REM,SALENO,ISALES,IQTY,ID01,TAG1,TAG2,IDAY,URLPATH2) values (";
        vsql = vsql + QuotedStr(surl) + ",";
        vsql = vsql + QuotedStr(surl2) + ",";
        vsql = vsql + QuotedStr(da3[n1]) + ",";
        vsql = vsql + QuotedStr(da4[n1]) + ",";
        vsql = vsql + QuotedStr(da2[n1]) + ",";
        vsql = vsql + QuotedStr(da1[n1]) + ",";
        //sss
        s2 = da3[n1];
        n3 = s2.IndexOf("天");
        if (n3 >= 0)
        {
          s2 = s2.Substring(n3 - 2, 2);
        }
        else
        {
          s2 = "";
        }
        nday = 0;
        try
        {
          nday = Int32.Parse(s2);

        }
        catch (FormatException)
        {
          nday = 0;
        }
        vsql = vsql + QuotedStr(s2) + ",";
        vsql = vsql + QuotedStr(da7[n1]) + ",";
        vsql = vsql + QuotedStr("0") + ",";
        vsql = vsql + QuotedStr("0") + ",";
        vsql = vsql + QuotedStr("0") + ",";
        vsql = vsql + QuotedStr(da5[n1]) + ",";
        vsql = vsql + QuotedStr(da6[n1]) + ",";
        vsql = vsql + QuotedStr("") + ",";
        //團號
        s2 = surl2;
        s3 = "TripNo=";
        n3 = s2.IndexOf("TripNo=");
        if (n3 > 0)
        {
          s2 = s2.Substring(n3 + 7);
        }
        s2=da9[n1];
        vsql = vsql + QuotedStr(s2) + ",";
        s2 = da7[n1];
        sa1 = s2.Split(",");
        if (s2.IndexOf(",") > 0)
        {
          s2 = sa1[0] + sa1[1];
        }
        s3 = "巨匠";
        vsql = vsql + s2 + "," + QuotedStr(da5[n1]) + "," + QuotedStr(s3) + "," + QuotedStr(st1) + "," + QuotedStr(da8[n1]) + "," + nday.ToString() + "," + QuotedStr(daa[n1]) + ");";
        aa1.Add(vsql);
        n1++;
      }
      if (aa1.Count > 0)
      {
        using (StreamWriter sw = File.CreateText("01.SQL"))
        {
          foreach (string s01 in aa1)
          {
            sw.WriteLine(s01);
          }
        }
        s1 = RunSQL_TRAN(aa1);
        Console.WriteLine(s1);
      }
      return s1;
    }

    public string QuotedStr(string S)
    {
      string vResult;
      vResult = S;
      for (int i = vResult.Length - 1; i >= 0; i--)
      {
        if (vResult[i].Equals('\''))
        {
          vResult = vResult.Insert(i, "\'");
        }
      }
      vResult = "'" + vResult + "'";
      return vResult;
    }

    public DataTable RunSQL(string sSQL)
    {
      SqlConnection ct = new SqlConnection(connectionString);
      ct.Open();
      SqlCommand command = new SqlCommand(sSQL, ct);
      SqlDataReader reader = command.ExecuteReader();
      DataTable dt = new DataTable();
      dt.Load(reader);
      ct.Close();
      return dt;
    }

    public int RunSQLc(string sSQL)
    {
      int i = 0;
      SqlConnection ct = new SqlConnection(connectionString);
      ct.Open();
      SqlCommand command = new SqlCommand(sSQL, ct);
      i = command.ExecuteNonQuery();
      ct.Close();
      return i;
    }

    public string RunSQL_TRAN(List<string> sSQL)
    {
      //
      string msg = "ok";
      SqlConnection ct = new SqlConnection(connectionString);
      SqlCommand sqlWrite = ct.CreateCommand();
      ct.Open();
      SqlTransaction trans = ct.BeginTransaction();
      sqlWrite.Transaction = trans;
      try
      {
        foreach (string s1 in sSQL)
        {
          sqlWrite.CommandText = s1;
          sqlWrite.ExecuteNonQuery();
        }
        trans.Commit();
      }
      catch (Exception)
      {
        trans.Rollback();
        msg = "ng";
      }
      finally
      {
        ct.Close();
        sqlWrite.Dispose();
        ct.Dispose();
        trans.Dispose();
      }
      return msg;
    }
  }
}