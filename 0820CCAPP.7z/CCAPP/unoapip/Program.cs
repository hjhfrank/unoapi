using System;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using apmssql;
using appsql;


var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      policy =>
                      {
                        policy.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                      });
});

var app = builder.Build();
//開固定port
//app.Urls.Add("https://localhost:3000");
app.Urls.Add("http://*:5055");
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseCors(MyAllowSpecificOrigins);

app.MapGet("/", () => "Hello World!");

app.MapPost("/listvvv", async (HttpRequest request) =>
{
    var body = new StreamReader(request.Body);
    string postData = await body.ReadToEndAsync();
    dynamic get_data = JObject.Parse(postData);
    string v011, v012, v021, v022, v031, v032, v041, v042, v051, v052, v07, vsql, s1;
    string v061, v062, v063, v064, v065, v066, v08, s2, v091, v092, v093, v043, v044, v045;
    string v046, v047, v048, v049, v04a, v04b, v04c, v04d, v04e, v04f, v10, v11, v12;
    string sv1, sv2;
    int n1, n2, n3, nv1;
    sv1 = "";
    sv2 = "";
    nv1 = 0;
    v011 = get_data["v011"];
    v012 = get_data["v012"];
    v021 = get_data["v021"];
    v022 = get_data["v022"];
    v031 = get_data["v031"];
    v032 = get_data["v032"];
    v041 = get_data["v041"];
    v042 = get_data["v042"];
    v043 = get_data["v043"];
    v044 = get_data["v044"];
    v045 = get_data["v045"];
    v046 = get_data["v046"];
    v047 = get_data["v047"];
    v048 = get_data["v048"];
    v049 = get_data["v049"];
    v04a = get_data["v04a"];
    v04b = get_data["v04b"];
    v04c = get_data["v04c"];
    v04d = get_data["v04d"];
    v04e = get_data["v04e"];
    v04f = get_data["v04f"];
    v051 = get_data["v051"];
    v052 = get_data["v052"];
    v061 = get_data["v061"];
    v062 = get_data["v062"];
    v063 = get_data["v063"];
    v064 = get_data["v064"];
    v065 = get_data["v065"];
    v066 = get_data["v066"];
    v07 = get_data["v07"];
    v08 = get_data["v08"];
    v091 = get_data["v091"];
    v092 = get_data["v092"];
    v093 = get_data["v093"];
    v10 = get_data["v10"];
    v11 = get_data["v11"];
    v12 = get_data["v12"];
    DataTable dt, dt1;
    //MssqlR t1 = new MssqlR();
    PssqlR t1 = new PssqlR();
    vsql = "";
    //vsql +="SELECT ALLID,CRTDT,URLPATH,URLPATH1,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,SIGNSTS,REM,SALENO";
    vsql += "SELECT ID01,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,SIGNSTS,REM,SALENO,CRTDT,ALLID,URLPATH,URLPATH1,URLPATH2,TAG1,TAG2";

    //vsql += " SELECT ID01,SALENO+PRODNAME V01,AIRLINE,STDATE+"("+WEEKOF+")" V02,T_DAY,SALES,QTY,SIGNSTS,CRTDT,ALLID,URLPATH,URLPATH1,PRODNAME,SALENO,STDATE,WEEKOF";
    vsql += " FROM P02V";
    vsql += " where STDATE>='" + v011 + "' and STDATE<='" + v012 + "'";
    if (v08 == "True")
    {
        vsql += " and ISALES>=" + v021 + " and ISALES<=" + v022;
    }
    vsql += " and IDAY>=" + v031 + " and IDAY<=" + v032;
    //原本的航空公司
    //vsql += " and AIRLINE>='" + v041 + "' and AIRLINE<='" + v042 + "'";
    s2 = "";
    if (v041 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='CI')";
        }
        else
        {
            s2 += " OR (AIRLINE='CI')";
        }
    }
    if (v042 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='BR')";
        }
        else
        {
            s2 += " OR (AIRLINE='BR')";
        }
    }
    if (v043 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='EK')";
        }
        else
        {
            s2 += " OR (AIRLINE='EK')";
        }
    }
    if (v044 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='TK')";
        }
        else
        {
            s2 += " OR (AIRLINE='TK')";
        }
    }
    if (v045 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='CX')";
        }
        else
        {
            s2 += " OR (AIRLINE='CX')";
        }
    }
    if (v046 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='KL')";
        }
        else
        {
            s2 += " OR (AIRLINE='KL')";
        }
    }
    if (v047 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='LH')";
        }
        else
        {
            s2 += " OR (AIRLINE='LH')";
        }
    }
    if (v048 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='SQ')";
        }
        else
        {
            s2 += " OR (AIRLINE='SQ')";
        }
    }
    if (v049 == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='SU')";
        }
        else
        {
            s2 += " OR (AIRLINE='SU')";
        }
    }
    if (v04a == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='TG')";
        }
        else
        {
            s2 += " OR (AIRLINE='TG')";
        }
    }
    if (v04b == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='QR')";
        }
        else
        {
            s2 += " OR (AIRLINE='QR')";
        }
    }
    if (v04c == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='CM')";
        }
        else
        {
            s2 += " OR (AIRLINE='CM')";
        }
    }
    if (v04d == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='CA')";
        }
        else
        {
            s2 += " OR (AIRLINE='CA')";
        }
    }
    if (v04e == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='HO')";
        }
        else
        {
            s2 += " OR (AIRLINE='HO')";
        }
    }
    if (v04f == "True")
    {
        if (s2 == "")
        {
            s2 = "(AIRLINE='MU')";
        }
        else
        {
            s2 += " OR (AIRLINE='MU')";
        }
    }
    if (s2 != "")
    {
        vsql = vsql + " and (" + s2 + ")";
    }
    s2 = "";
    if (v061 == "True")
    {
        if (s2 == "")
        {
            s2 = "(SIGNSTS='報名')";
        }
        else
        {
            s2 += " OR (SIGNSTS='報名')";
        }
    }
    if (v062 == "True")
    {
        if (s2 == "")
        {
            s2 = "(SIGNSTS='候補')";
        }
        else
        {
            s2 += " OR (SIGNSTS='候補')";
        }
    }
    if (v063 == "True")
    {
        if (s2 == "")
        {
            s2 = "(SIGNSTS='即將成團')";
        }
        else
        {
            s2 += " OR (SIGNSTS='即將成團')";
        }
    }
    if (v064 == "True")
    {
        if (s2 == "")
        {
            s2 = "(SIGNSTS='已成團')";
        }
        else
        {
            s2 += " OR (SIGNSTS='已成團')";
        }
    }
    if (v065 == "True")
    {
        if (s2 == "")
        {
            s2 = "(SIGNSTS='保證出團')";
        }
        else
        {
            s2 += " OR (SIGNSTS='保證出團')";
        }
    }
    if (v066 == "True")
    {
        if (s2 == "")
        {
            s2 = "(SIGNSTS='結團')";
        }
        else
        {
            s2 += " OR (SIGNSTS='結團')";
        }
    }
    if (s2 != "")
    {
        vsql = vsql + " and (" + s2 + ")";
    }
    string[] sa1;
    s2 = "";
    if (v07 != "")
    {
        sa1 = v07.Split(",");
        n1 = 0;
        n2 = sa1.Length - 1;
        while (n1 <= n2)
        {
            s1 = sa1[n1];
            if (n1 == 0)
            {
                s2 += " and ((PRODNAME LIKE '%" + s1 + "%')";
            }
            if ((n1 > 0) & (n1 < n2))
            {
                s2 += " or (PRODNAME LIKE '%" + s1 + "%')";
            }
            if (n1 == n2)
            {
                s2 += " or (PRODNAME LIKE '%" + s1 + "%'))";
            }
            n1++;
        }
        vsql += s2;
    }
    s2 = "";
    if (v11 != "")
    {
        sa1 = v11.Split(",");
        n1 = 0;
        n2 = sa1.Length - 1;
        while (n1 <= n2)
        {
            s1 = sa1[n1];
            if (n1 == 0)
            {
                s2 += " and ((TAG1 LIKE '%" + s1 + "%')";
            }
            if ((n1 > 0) & (n1 < n2))
            {
                s2 += " or (TAG1 LIKE '%" + s1 + "%')";
            }
            if (n1 == n2)
            {
                s2 += " or (TAG1 LIKE '%" + s1 + "%'))";
            }
            n1++;
        }
        vsql += s2;
    }
    s2 = "";
    if (v10 != "")
    {
        sa1 = v10.Split(",");
        n1 = 0;
        n2 = sa1.Length - 1;
        while (n1 <= n2)
        {
            s1 = sa1[n1];
            if (n1 == 0)
            {
                s2 += " and ((TAG2 LIKE '%" + s1 + "%')";
            }
            if ((n1 > 0) & (n1 < n2))
            {
                s2 += " or (TAG2 LIKE '%" + s1 + "%')";
            }
            if (n1 == n2)
            {
                s2 += " or (TAG2 LIKE '%" + s1 + "%'))";
            }
            n1++;
        }
        vsql += s2;
    }
    s2 = "";
    if ((v091 == "True") & (v092 == "True") & (v093 == "True"))
    {
        s2 = "";
    }
    else
    {
        s2 = " AND (";
        if (v091 == "True")
        {
            s2 = s2 + "(ID01='鳳凰')";
        }
        if (v092 == "True")
        {
            if (s2.IndexOf("ID01") > 0)
            {
                s2 = s2 + " OR (ID01='永信')";
            }
            else
            {
                s2 = s2 + "(ID01='永信')";
            }
        }
        if (v093 == "True")
        {
            if (s2.IndexOf("ID01") > 0)
            {
                s2 = s2 + " OR (ID01='巨匠')";
            }
            else
            {
                s2 = s2 + "(ID01='巨匠')";
            }
        }
        if (s2.Length > 0)
        {
            s2 = s2 + ")";
        }
    }
    vsql += s2;
    //vsql+=" and SALENO='EOE080710BR24C'";
    //vsql += " order by PRODNAME,ALLID,SALENO";
    if (v12 == "1")
    {
        vsql += " order by STDATE,ALLID,PRODNAME";
    }
    else
    {
        vsql += " order by PRODNAME,ALLID,STDATE";
    }
    Console.WriteLine(vsql);
    dt = t1.RunSQL(vsql);
    dt1 = dt.Clone();
    DataRow r1;
    //把dt導入dt1    
    foreach (DataRow row in dt.Rows)
    {
        //Console.WriteLine(row["ALLID"]);
        s1 = row["SALENO"].ToString();
        n2 = dt1.Rows.Count - 1;
        n1 = 0;
        n3 = 1;
        while (n1 <= n2)
        {
            r1 = dt1.Rows[n1];
            s2 = r1["SALENO"].ToString();
            if (s1 == s2)
            {
                n3 = 0;
                dt1.Rows.RemoveAt(n1);
                dt1.AcceptChanges();
                dt1.ImportRow(row);
                n1 = 99999;
            }
            n1++;
        }
        if (n3 == 1)
        {
            dt1.ImportRow(row);
        }
    }
    foreach (DataRow row in dt1.Rows)
    {
        r1 = row;
        sv1 = r1["SALENO"].ToString();
        sv2 = r1["ID01"].ToString();
        if (sv2 == "巨匠")
        {
            nv1 = sv1.IndexOf("=");
            sv1 = sv1.Substring(nv1 + 1);
            nv1 = sv1.IndexOf("&");
            sv1 = sv1.Substring(0, nv1);
            row.BeginEdit();
            row["SALENO"] = sv1;
            row.AcceptChanges();
        }
    }
    s1 = JsonConvert.SerializeObject(dt1);
    //s1 = JsonConvert.SerializeObject(dt);   
    //很奇怪,postgresql可能需要的是"
    string jret = "{\"" + "dt"+"\""+ ":" + s1 + "}";
    //Console.Write(jret);
    return jret;
});

app.MapPost("/listvvv2", async (HttpRequest request) =>
{
    var body = new StreamReader(request.Body);
    string postData = await body.ReadToEndAsync();
    dynamic get_data = JObject.Parse(postData);
    string sno, vsql, s1, sv1, sv2;
    int nv1;
    sno = get_data["sno"];
    s1 = "%" + sno + "%";
    sv1 = "";
    sv2 = "";
    nv1 = 0;
    DataTable dt;
    DataRow r1;
    MssqlR t1 = new MssqlR();
    vsql = "SELECT ID01,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,SIGNSTS,REM,SALENO,CRTDT,ALLID,URLPATH,URLPATH1,URLPATH2,TAG1,TAG2";
    vsql += " FROM P02V";
    vsql += " WHERE SALENO like '" + s1 + "'";
    vsql += " order by ALLID";
    dt = t1.RunSQL(vsql);
    foreach (DataRow row in dt.Rows)
    {
        r1 = row;
        sv1 = r1["SALENO"].ToString();
        sv2 = r1["ID01"].ToString();
        if (sv2 == "巨匠")
        {
            nv1 = sv1.IndexOf("=");
            sv1 = sv1.Substring(nv1 + 1);
            nv1 = sv1.IndexOf("&");
            sv1 = sv1.Substring(0, nv1);
            row.BeginEdit();
            row["SALENO"] = sv1;
            row.AcceptChanges();
        }
    }
    s1 = JsonConvert.SerializeObject(dt);
    string jret = "{" + t1.QuotedStr("dt") + ":" + s1 + "}";
    return jret;
});

app.Run();