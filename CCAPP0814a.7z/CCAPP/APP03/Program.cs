﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Browser;

namespace APP03;

class Program
{
    static void Main(string[] args)
    {
        //int npp = Int32.Parse(args[0]);
        string spp = args[0];

        //string spp = "11";

        //先爬鳳凰旅行社,鳳凰只有1條歐洲線其他不考慮
        MssqlR t1 = new MssqlR();
        DataTable dt;
        //DateTime vdt;
        string vsql;
        vsql = "SELECT ALLID,URLPATH,TAG1,TAG2,ID01 FROM P01V";
        vsql = vsql + " where ALLID=" + spp;
        string[] sa1;
        dt = t1.RunSQL(vsql);
        int n1, n2, n3, n4, n5, n6, nl, nday;
        n1 = 0;
        n2 = 0;
        nday = 0;
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> da1 = new List<string>();
        List<string> da2 = new List<string>();
        List<string> da3 = new List<string>();
        List<string> da4 = new List<string>();
        List<string> da5 = new List<string>();
        List<string> da6 = new List<string>();
        List<string> da7 = new List<string>();
        List<string> da8 = new List<string>();
        List<string> da9 = new List<string>();
        List<string> daa = new List<string>();
        List<string> dab = new List<string>();
        List<string> dac = new List<string>();
        List<string> dad = new List<string>();
        string s1, s2, s3, st1, st2, st3, sid01, surl1, surl2;
        st1 = "";
        st2 = "";
        surl1 = "";
        surl2 = "";
        while (n1 <= n2)
        {
            nl = 0;
            IWebDriver driver = new ChromeDriver();
            s1 = dt.Rows[n1]["ALLID"].ToString();
            s2 = dt.Rows[n1]["URLPATH"].ToString();
            surl1 = s2;
            surl2 = s2;
            st1 = dt.Rows[n1]["TAG1"].ToString();
            st2 = dt.Rows[n1]["TAG2"].ToString();
            sid01 = dt.Rows[n1]["ID01"].ToString();
            driver.Navigate().GoToUrl(s2);
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);
            s3 = driver.PageSource;
            using (StreamWriter sw = File.CreateText("1.txt"))
            {
                sw.WriteLine(s3);
            }

            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        aa1.Add(line);
                    }
                }
            }
            driver.Close();
            driver.Quit();
            n1++;
        }

        n1 = 0;
        n2 = aa1.Count - 1;
        while (n1 <= n2)
        {
            aa2.Add(aa1[n1]);
            n1++;
        }
        n1 = 0;
        while (n1 <= n2)
        {
            s1 = aa1[n1];
            n3 = s1.IndexOf("<a href=");
            n4 = s1.IndexOf("/products");
            n5 = s1.IndexOf("group/search");
            if ((n3 >= 0) & (n4 >= 0) & (n5 < 0))
            {
                nl = 0;
                n6 = n1;
                while (nl == 0)
                {
                    n6++;
                    s1 = s1 + aa2[n6];
                    if (s1.IndexOf("</a>") > 0)
                    {
                        aa3.Add(s1);
                        nl = 1;
                    }
                }
                n1 = n6;
            }
            n1++;
        }
        n1 = 0;
        n2 = aa3.Count - 1;
        using (StreamWriter sw = File.CreateText("90.txt"))
        {
            while (n1 <= n2)
            {
                sw.WriteLine(aa3[n1]);
                n1++;
            }
        }
        n1 = 0;
        aa1.Clear();
        aa2.Clear();
        while (n1 <= n2)
        {
            s1 = aa3[n1];
            if (spp == "11")
            {
                if (s1.IndexOf("/detail/") < 0)
                {
                    aa1.Add(s1);
                }
            }
            else
            {
                aa1.Add(aa3[n1]);
            }
            n1++;
        }
        n1 = 0;
        n2 = aa1.Count - 1;
        aa3.Clear();
        while (n1 <= n2)
        {
            s1 = aa1[n1];
            n3 = s1.IndexOf("<a href=");
            if (n3 >= 0)
            {
                s1 = s1.Substring(n3 + 9);
                n4 = s1.IndexOf("\"");
                s1 = s1.Substring(0, n4);
                n4 = s1.IndexOf("ystravel.com.tw");
                if (n4 < 0)
                {
                    s1 = "https://www.ystravel.com.tw" + s1;
                }
                aa2.Add(s1);
            }
            s1 = aa1[n1];
            n3 = s1.IndexOf("<h3");
            n4 = s1.IndexOf("</h3>");
            s1 = s1.Substring(n3, n4 - n3);
            n3 = s1.IndexOf(">");
            s1 = s1.Substring(n3 + 1);
            aa3.Add(s1);
            n1++;
        }
        n1 = 0;
        n2 = aa3.Count - 1;
        using (StreamWriter sw = File.CreateText("1.txt"))
        {
            while (n1 <= n2)
            {
                sw.WriteLine(aa3[n1]);
                n1++;
            }
        }
        aa1.Clear();
        n1 = 0;
        n2 = aa2.Count - 1;
        while (n1 <= n2)
        {
            aa1.Add(aa2[n1]);
            n1++;
        }
        aa2.Clear();
        n1 = 0;
        n2 = aa3.Count - 1;
        while (n1 <= n2)
        {
            aa2.Add(aa3[n1]);
            n1++;
        }
        aa3.Clear();
        n1 = 0;
        n2 = aa1.Count - 1;
        while (n1 <= n2)
        {
            IWebDriver driver = new ChromeDriver();
            s1 = aa1[n1];
            st3 = s1;
            surl1 = aa1[n1];
            driver.Navigate().GoToUrl(s1);
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);
            s2 = driver.PageSource;
            using (StreamWriter sw = File.CreateText("1.txt"))
            {
                sw.WriteLine(s2);
            }
            driver.Close();
            driver.Quit();
            nl = 0;
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    n3 = line.IndexOf("<tr data-prod-idx=");
                    if (n3 > 0) { nl = 1; }
                    n4 = line.IndexOf("</tbody>");
                    if (n4 > 0) { nl = 0; }
                    if (nl == 1)
                    {
                        aa3.Add(line);
                    }
                }
            }
            n3 = 0;
            n4 = aa3.Count - 1;
            while (n3 <= n4)
            {
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "go-date" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 22);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    sa1 = s1.Split("/");
                    s1 = sa1[0] + "-" + sa1[1] + "-" + sa1[2];
                    da1.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("class=" + "\"" + "item_days" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 18);
                    n6 = s1.IndexOf("<");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da2.Add(s1);
                }
                //取得名稱
                s1 = aa3[n3];
                n5 = s1.IndexOf("class=" + "\"" + "title_main" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 19);
                    n6 = s1.IndexOf("</a>");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da3.Add(s1);
                    //取得產品連結
                    s1 = aa3[n3];
                    n5 = s1.IndexOf("<a href=");
                    if (n5 > 0)
                    {
                        s1 = s1.Substring(n5 + 9);
                        n5 = s1.IndexOf("class");
                        s1 = s1.Substring(0, n5 - 2);
                        //Console.WriteLine(s1);
                        //https://www.ystravel.com.tw/products/group/mold/ZRH14CXH
                        s2=s1;
                        n5=s2.IndexOf("=");
                        if (n5>0)
                        {
                            s2=s2.Substring(n5+1);
                        }   
                        dad.Add(s2);
                        s1="https://www.ystravel.com.tw"+s1;
                        dac.Add(s1);
                    }
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "plane-abbr" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 25);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da4.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "機位：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da5.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "已售：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da6.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "候補：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    //Console.WriteLine(s1);
                    da7.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<td data-th=" + "\"" + "可售：" + "\"");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</td");
                    s1 = s1.Substring(0, n6);
                    da8.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("<span class=" + "\"" + "text-danger" + "\"" + ">NT$");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 20);
                    n6 = s1.IndexOf(">");
                    s1 = s1.Substring(n6 + 1);
                    n6 = s1.IndexOf("</span>");
                    s1 = s1.Substring(0, n6);
                    da9.Add(s1);
                }
                s1 = aa3[n3];
                n5 = s1.IndexOf("btn_book");
                if (n5 > 0)
                {
                    s1 = s1.Substring(n5 + 10);
                    n6 = s1.IndexOf("</a>");
                    s1 = s1.Substring(0, n6);
                    n6 = s1.IndexOf(">");
                    if (n6 > 0)
                    {
                        s1 = s1.Substring(n6 + 1);
                    }
                    //Console.WriteLine(s1);
                    if (s1 == "截止")
                    {
                        s1 = "結團";
                    }
                    daa.Add(s1);
                }
                dab.Add(surl1);
                n3++;
            }

            n1++;
        }
        n1 = 0;
        n2 = da1.Count - 1;
        while (n1 <= n2)
        {
            using (StreamWriter sw = File.CreateText("2.txt"))
            {
                while (n1 <= n2)
                {
                    s1 = da1[n1] + "," + da2[n1] + "," + da3[n1] + "," + da4[n1] + "," + da5[n1] + "," + da6[n1] + "," + da7[n1] + "," + da8[n1] + "," + da9[n1] + "," + daa[n1] + "," + dab[n1];
                    sw.WriteLine(s1);
                    n1++;
                }
            }
        }
        aa1.Clear();
        n1 = 0;
        while (n1 <= n2)
        {
            vsql = "insert into P02V (URLPATH,URLPATH1,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,";
            vsql = vsql + "SIGNSTS,REM,SALENO,ISALES,IQTY,ID01,TAG1,TAG2,IDAY,URLPATH2) values (";
            vsql = vsql + t1.QuotedStr(dab[n1]) + ",";
            vsql = vsql + t1.QuotedStr(dab[n1]) + ",";
            vsql = vsql + t1.QuotedStr(da3[n1]) + ",";
            s1 = da4[n1];
            if (s1 == "土耳其航空") { s1 = "TK"; }
            if (s1 == "中華航空") { s1 = "CI"; }
            if (s1 == "卡達航空") { s1 = "QR"; }
            if (s1 == "長榮航空") { s1 = "BR"; }
            if (s1 == "阿聯酋航空") { s1 = "EK"; }
            if (s1 == "泰國航空") { s1 = "TG"; }
            if (s1 == "國泰航空") { s1 = "CX"; }
            if (s1 == "新加坡航空") { s1 = "SQ"; }
            vsql = vsql + t1.QuotedStr(s1) + ",";
            s1 = da1[n1];
            s1 = s1.Substring(0, 10);
            vsql = vsql + t1.QuotedStr(s1) + ",";
            //這邊很奇怪抓錯,改用日期抓星期幾
            s1 = da1[n1];
            n3=s1.IndexOf("(");
            //s2 = s1.Substring(n3);
            s2 = s1.Substring(n3+1,1);
            vsql = vsql + t1.QuotedStr(s2) + ",";
            vsql = vsql + t1.QuotedStr(da2[n1]) + ",";
            s1 = da9[n1];
            n3 = 3;
            s1 = s1.Substring(n3);
            vsql = vsql + t1.QuotedStr(s1) + ",";
            vsql = vsql + t1.QuotedStr("0") + ",";
            vsql = vsql + t1.QuotedStr("0") + ",";
            vsql = vsql + t1.QuotedStr("0") + ",";
            vsql = vsql + t1.QuotedStr(da8[n1]) + ",";
            vsql = vsql + t1.QuotedStr(daa[n1]) + ",";
            vsql = vsql + t1.QuotedStr("") + ",";
            sa1 = [];
            s1 = dab[n1];
            sa1 = s1.Split('/');
            s2 = sa1[sa1.Length - 1];
            ///Console.WriteLine(s2);
            s1 = da1[n1];
            s1 = s1.Substring(0, 10);
            //Console.WriteLine(s1);
            //sa1 = [];
            //sa1 = s1.Split('/');
            s3 = sa1[0] + sa1[1] + sa1[2];
            n3 = s2.Length;
            //Console.WriteLine(n3);
            s1 = s2.Substring(0, n3 - 1) + s3 + s2.Substring(n3 - 1, 1);
            //Console.WriteLine(da1[n1]);
            vsql = vsql + t1.QuotedStr(dad[n1]);
            s1 = da9[n1];
            n3 = 3;
            s1 = s1.Substring(n3);
            n3 = s1.IndexOf(",");
            if (n3 > 0)
            {
                s2 = s1.Substring(0, n3) + s1.Substring(n3 + 1);
            }
            else
            {
                s2 = s1;
            }
            nday = 0;

            try
            {
                nday = Int32.Parse(da2[n1]);
            }
            catch (FormatException)
            {
                n1 = 0;
            }
            vsql = vsql + "," + s2 + "," + da8[n1] + "," + t1.QuotedStr("永信") + "," + t1.QuotedStr(st1) + "," + t1.QuotedStr(st2) + "," + nday.ToString() +","+t1.QuotedStr(dac[n1])+ ");";
            aa1.Add(vsql);
            n1++;
        }
        if (aa1.Count > 0)
        {
            using (StreamWriter sw = File.CreateText("01.SQL"))
            {
                foreach (string s01 in aa1)
                {
                    sw.WriteLine(s01);
                }
            }
            s1 = t1.RunSQL_TRAN(aa1);
            Console.WriteLine(s1);
        }

    }
}
