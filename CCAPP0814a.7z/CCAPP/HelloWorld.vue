<template>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">篩選公司:</div>
    <el-checkbox v-model="v091" label="鳳凰" />
    <el-checkbox v-model="v092" label="永信" />
    <el-checkbox v-model="v093" label="巨匠" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">出發日期起迄:</div>
    <el-date-picker v-model="v011" type="date" style="width:150px" />
    <div style="font-size:24px">～</div>
    <el-date-picker v-model="v012" type="date" style="width:150px" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">旅遊天數:</div>
    <el-input v-model="v031" style="width: 40px;text-align: left;" />
    <div style="font-size:18px">～</div>
    <el-input v-model="v032" style="width: 40px;text-align: left;" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">航空公司:</div>
    <el-checkbox v-model="v041" label="CI 中華航空" />
    <el-checkbox v-model="v042" label="BR 長榮航空" />
    <el-checkbox v-model="v043" label="EK 阿聯酋航空" />
    <el-checkbox v-model="v044" label="TK 土耳其航空 " />
    <el-checkbox v-model="v045" label="CX 國泰航空" />
    <el-checkbox v-model="v046" label="KL 荷蘭皇家航空 " />
    <el-checkbox v-model="v047" label="LH 漢莎航空" />
    <el-checkbox v-model="v048" label="SQ 新加坡航空" />
    <el-checkbox v-model="v049" label="SU 俄羅斯航空 " />
    <el-checkbox v-model="v04a" label="TG 泰國國際航空" />
    <el-checkbox v-model="v04b" label="QR 卡達航空" />
    <el-checkbox v-model="v04c" label="OM 蒙古民用航空" />
    <el-checkbox v-model="v04d" label="CA 中國國際航空" />
    <el-checkbox v-model="v04e" label="HO 吉祥航空" />
    <el-checkbox v-model="v04f" label="MU 中國東方航空 " />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">團費區間:</div>
    <el-input v-model="v021" style="width: 100px;text-align: left;" />
    <div style="font-size:18px">～</div>
    <el-input v-model="v022" style="width: 100px;text-align: left;" />
    <el-checkbox v-model="v08" label="加入篩選(請注意本項加入無法顯示鳳凰結團資料)" style="padding-left: 5px;" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">團體狀態:</div>
    <el-checkbox v-model="v061" label="報名" />
    <el-checkbox v-model="v062" label="候補" />
    <el-checkbox v-model="v063" label="即將成團" />
    <el-checkbox v-model="v064" label="已成團 " />
    <el-checkbox v-model="v065" label="保證出團" />
    <el-checkbox v-model="v066" label="結團" />
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <div style="font-size:18px;padding-top: 3px;">產品名稱關鍵字:</div>
    <el-input v-model="v07" style="width: 200px" placeholder="產品名稱關鍵字">
    </el-input>
    <div style="font-size:18px;padding-left: 3px;padding-top: 3px;">國家關鍵字:</div>
    <el-input v-model="v10" style="width: 200px" placeholder="國家關鍵字">
    </el-input>
    <div style="font-size:18px;padding-left: 3px;padding-top: 3px;">地區關鍵字:</div>
    <el-input v-model="v11" style="width: 200px" placeholder="地區關鍵字">
    </el-input>
  </el-row>
  <el-row>
    <div style="height:3px"></div>
    <div style="font-size:18px;padding-top: 8px;">排序:</div>
    <el-radio-group v-model="v12">
      <el-radio value="1" size="large">出發日期+產品名稱</el-radio>
      <el-radio value="2" size="large">產品名稱+出發日期</el-radio>
    </el-radio-group>
  </el-row>
  <div style="height:5px"></div>
  <el-row>
    <el-button @click="btn1()">條件搜尋+關鍵字</el-button>
    <el-button @click="btn5()">團號搜尋</el-button>
    <el-button v-if="isshow1" type="primary" @click="btn2">Excel輸出</el-button>
    <template v-if="isshow1"><span style="padding-left: 10px;padding-top: 4px;color: blue;">共{{ vrec }}筆</span></template>
  </el-row>
  <template v-if="isshow1">
    <div style="height:3px"></div>
    <el-table :data="srrec" style="width: 100%" id="excelo">
      <el-table-column prop="ID01" label="公司" width="60" />
      <el-table-column prop="CRTDT" label="收集日期" width="150" />
      <el-table-column prop="STDATE,WEEKOF" label="出發日" width="120">
        <template #default="scope">
          {{ scope.row.STDATE }}({{ scope.row.WEEKOF }})
        </template>
      </el-table-column>
      <el-table-column prop="SIGNSTS" label="報名" width="60" />
      <el-table-column prop="SALENO,PRODNAME,URLPATH2" label="名稱" width="550">
        <template #default="scope">
          {{ scope.row.SALENO }} <br>
          {{ scope.row.PRODNAME }} <br>
          <el-button @click="btnURL($event)" style="border-style: none;background-color: transparent;">
            {{ scope.row.URLPATH2 }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column prop="AIRLINE" label="班機" width="60" />
      <el-table-column prop="T_DAY" label="天數" width="60" />
      <el-table-column prop="SALES" label="團費" width="80" />
      <el-table-column prop="QTY" label="機位" width="60" />
    </el-table>
  </template>
  <el-dialog v-model="isdlg1" title="團號歷史查詢" width="300">
    <el-input v-model="sno" style="width: 100%" />
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dlg1btn(1)">放棄</el-button>
        <el-button type="primary" @click="dlg1btn(2)">
          確定
        </el-button>
      </div>
    </template>
  </el-dialog>
  <el-dialog v-model="isdlg2" title="Excel檔案名稱" width="300">
    <el-input v-model="dnfile" style="width: 100%" />
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dlg2btn(1)">放棄</el-button>
        <el-button type="primary" @click="dlg2btn(2)">
          確定
        </el-button>
      </div>
    </template>
  </el-dialog>
  <el-dialog v-model="isdlg3" title="查詢等待" width="300">
    <el-row>查詢中</el-row>
  </el-dialog>
</template>

<script>
import { defineComponent, ref } from 'vue';
import axios from 'axios';
import dayjs from 'dayjs';
import * as XLSX from "xlsx";

export default defineComponent({
  name: "HelloWorld",
  data() {
    return {
      v011: dayjs(),
      v012: dayjs(),
      v021: '10000',
      v022: '200000',
      v031: '7',
      v032: '14',
      //v041: 'BR',
      //v042: 'TK',
      v041: false,
      v042: false,
      v043: false,
      v044: false,
      v045: false,
      v046: false,
      v047: false,
      v048: false,
      v049: false,
      v04a: false,
      v04b: false,
      v04c: false,
      v04d: false,
      v04e: false,
      v04f: false,
      v051: '日',
      v052: '六',
      v061: false,
      v062: false,
      v063: false,
      v064: false,
      v065: false,
      v066: false,
      v07: '',
      v08: true,
      v091: true,
      v092: true,
      v093: true,
      v10: '',
      v11: '',
      v12: '1',
      srrec: [],
      srrec1: [],
      isshow1: false,
      sno: '',
      isdlg1: false,
      isdlg2: false,
      isdlg3: false,
      dnfile: dayjs().format('YYYYMMDD'),
      nselbtn: 0,
      vrec: 0,
    };
  },
  //巨匠滿團仍有人數,滿團視為結團
  //可報名->報名
  //滿團可候補,滿候補->候補
  //永信
  //截止->結團
  //鳳凰先改
  methods: {
    btnURL(e) {
      let s1;
      s1 = e.target.innerText;
      window.open(s1, '_blank');
    },
    async btn1() {
      this.isshow1 = false;
      this.isdlg3 = true;
      let param = {
        'v011': dayjs(this.v011).format('YYYY-MM-DD'),
        'v012': dayjs(this.v012).format('YYYY-MM-DD'),
        'v021': this.v021,
        'v022': this.v022,
        'v031': this.v031,
        'v032': this.v032,
        'v041': this.v041,
        'v042': this.v042,
        'v043': this.v043,
        'v044': this.v044,
        'v045': this.v045,
        'v046': this.v046,
        'v047': this.v047,
        'v048': this.v048,
        'v049': this.v049,
        'v04a': this.v04a,
        'v04b': this.v04b,
        'v04c': this.v04c,
        'v04d': this.v04d,
        'v04e': this.v04e,
        'v04f': this.v04f,
        'v051': this.v051,
        'v052': this.v052,
        'v061': this.v061,
        'v062': this.v062,
        'v063': this.v063,
        'v064': this.v064,
        'v065': this.v065,
        'v066': this.v066,
        'v07': this.v07,
        'v08': this.v08,
        'v091': this.v091,
        'v092': this.v092,
        'v093': this.v093,
        'v10': this.v10,
        'v11': this.v11,
        'v12': this.v12,
      }
      this.ex = await this.btn11(param);
    },
    btn11(param) {
      return new Promise((res, rej) => {
        axios({
          method: 'POST',
          //url: "http://localhost:5055/listvvv",
          url: "http://192.168.1.189:3000/listvvv",
          data: param
        }).then(async (res) => {
          this.srrec = res.data.dt;
          if (this.srrec.length > 0) {
            this.vrec = this.srrec.length;
            this.isshow1 = true;
          }
          else { alert('搜尋不到資料') }
          this.isdlg3 = false;
        }).catch((error) => {
          alert('網路出現錯誤');
        });
      });
    },
    async dlg1btn(nn) {
      this.isshow1 = false;
      //this.isdlg3 = true;
      if (nn == 2) {
        let param = { 'sno': this.sno };
        this.isdlg3 = true;
        this.ex = await this.dlg1btn1(param);
      }
      this.isdlg1 = false;
    },
    dlg1btn1(param) {
      return new Promise((res, rej) => {
        axios({
          method: 'POST',
          //url: "http://localhost:5055/listvvv2",
          url: "http://192.168.1.189:3000/listvvv2",                           
          data: param
        }).then(async (res) => {
          this.srrec = res.data.dt;
          this.isdlg1 = false;
          this.isdlg3 = false;
          if (this.srrec.length > 0) {
            this.isshow1 = true;
            this.vrec=this.srrec.length;
          }
          else { alert('搜尋不到資料') }
          //this.isdlg1 = false;
          //this.isdlg3 = false;
        }).catch((error) => {
          alert('網路出現錯誤');
        });
      });
    },
    dlg2btn(nn) {
      if (nn == 2) {
        if (this.dnfile.indexOf('.') < 0) {
          this.dnfile = this.dnfile + '.xlsx';
        }
        this.btn21();
      }
      this.isdlg2 = false;
    },
    btn2() {
      this.isdlg2 = true;
    },
    btn21() {
      //我直接加表頭
      let n1, n2;
      let a1 = [];
      let aa1 = [];
      let j1 = {};
      //ID01,PRODNAME,AIRLINE,STDATE,WEEKOF,T_DAY,SALES,VISAC,TAXC,TIPC,QTY,SIGNSTS,REM,SALENO,CRTDT,ALLID,URLPATH2,URLPATH1           
      aa1 = ["公司", "收集日期", "出發日", "報名", "產品名稱", "班機", "天數", "團費", "機位", "產品網址", "查詢網址"];
      a1.push(aa1);
      n1 = 0;
      n2 = this.srrec.length - 1;
      while (n1 <= n2) {
        j1 = this.srrec[n1];
        aa1 = [j1["ID01"], j1["CRTDT"], j1["STDATE"] + "(" + j1["WEEKOF"] + ")", j1["SIGNSTS"], j1["SALENO"] + " " + j1["PRODNAME"], j1["AIRLINE"], j1["T_DAY"], j1["SALES"], j1["QTY"], j1["URLPATH2"], j1["URLPATH1"]];
        a1.push(aa1)
        n1++;
      }
      const workbook = XLSX.utils.book_new();
      //const worksheet = XLSX.utils.json_to_sheet(this.srrec);
      const worksheet = XLSX.utils.aoa_to_sheet(a1);
      let wscols = [
        { wch: 5 },
        { wch: 16 },
        { wch: 12 },
        { wch: 10 },
        { wch: 60 },
        { wch: 8 },
        { wch: 8 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
        { wch: 10 },
      ];
      worksheet['!cols'] = wscols;
      XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
      this.saveExcelFile(excelBuffer, this.dnfile);
    },
    //這個要修,有空
    saveExcelFile(buffer, filename) {
      const data = new Blob([buffer], {
        type: "application/octet-stream",
      });
      const url = URL.createObjectURL(data);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    },
    btn3() {
      alert('ok3');
    },

    btn5() {
      //EUF082611TK24A
      this.isshow1 = false;
      this.isdlg1 = true;
    }
  },
  created() {
    let v1 = dayjs();
    let v2 = v1.add(1, 'month');
    this.v011 = v1;
    this.v012 = v2;
  },
  /*
   <el-row>
    <div style="font-size:24px">團費區間:</div>
    <el-input v-model="v021" style="width: 100px;text-align: left;" />
    <div style="font-size:24px">～</div>
    <el-input v-model="v022" style="width: 100px;text-align: left;" />
  </el-row>
  <div style="font-size:24px">航空公司:</div>
    <el-input v-model="v041" style="width: 40px;text-align: left;" />
    <div style="font-size:24px">～</div>
    <el-input
     <el-row>
    <div style="font-size:18px;padding-top: 3px;">航空公司:</div>
    <el-checkbox v-model="v041" label="CI 中華航空" />
    <el-checkbox v-model="v042" label="BR 長榮航空" />
    <el-checkbox v-model="v043" label="EK 阿聯酋航空" />
    <el-checkbox v-model="v044" label="TK 土耳其航空 " />
    <el-checkbox v-model="v045" label="CX 國泰航空" />   
  </el-row>
  公司
收集日期
出發日
報名	
名稱	
班機	
天數	
團費	
機位

  */
});

</script>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
