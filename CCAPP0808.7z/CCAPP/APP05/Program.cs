﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium.Firefox;
using System;
using System.Threading.Tasks;
using System.Threading;
using apmssql;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Runtime.Intrinsics.Arm;
using System.Runtime.InteropServices.ComTypes;
using OpenQA.Selenium.DevTools.V125.Network;

namespace APP05;

class Program
{
    static void Main(string[] args)
    {
        //int npp = Int32.Parse(args[0]);
        string spp = args[0];
        //string spp = "4";

        MssqlR t1 = new MssqlR();
        DataTable dt;
        string vsql;
        vsql = "SELECT ALLID,URLPATH,TAG1,TAG2,ID01 FROM P01V";
        vsql = vsql + " where ALLID=" + spp;
        dt = t1.RunSQL(vsql);
        int n1, n2, n3, n4, n5, n6, nl, n7, n8;
        n1 = 0;
        n2 = 0;
        n7 = 0;
        n8 = 0;
        List<string> aa1 = new List<string>();
        List<string> aa2 = new List<string>();
        List<string> aa3 = new List<string>();
        List<string> aa4 = new List<string>();
        List<string> da1 = new List<string>();
        List<string> da2 = new List<string>();
        List<string> da3 = new List<string>();
        List<string> da4 = new List<string>();
        List<string> da5 = new List<string>();
        List<string> da6 = new List<string>();
        List<string> da7 = new List<string>();
        List<string> da8 = new List<string>();
        List<string> da9 = new List<string>();
        List<string> daa = new List<string>();
        List<string> dab = new List<string>();
        string s1, s2, s3, st1, st2, surl, surl2;
        string[] sa1;
        surl = "";
        surl2 = "";
        st1 = "";
        st2 = "";
        while (n1 <= n2)
        {
            IWebDriver driver = new ChromeDriver();
            s1 = dt.Rows[n1]["ALLID"].ToString();
            s2 = dt.Rows[n1]["URLPATH"].ToString();
            st1 = dt.Rows[n1]["TAG1"].ToString();
            st2 = dt.Rows[n1]["TAG2"].ToString();
            surl = s2;
            driver.Navigate().GoToUrl(s2);
            driver.Manage().Window.Maximize();
            Thread.Sleep(5000);
            s3 = driver.PageSource;
            using (StreamWriter sw = File.CreateText("1.txt"))
            {
                sw.WriteLine(s3);
            }
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        aa1.Add(line);
                    }
                }
            }
            //T20231127000003             
            using (StreamReader sr = new StreamReader("1.txt"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (line != "")
                    {
                        aa1.Add(line);
                    }
                }
            }
            //st2抓的關鍵字
            //class="Exhibition_filter_group" id=
            //產品關鍵字
            //ClassifyProduct.aspx?TripNo=
            driver.Close();
            driver.Quit();
            n1++;
        }
        n1 = 0;
        n2 = aa1.Count - 1;
        //n2=0;
        while (n1 <= n2)
        {
            s1 = aa1[n1];
            /*
            n3 = s1.IndexOf("class=" + "\"" + "Exhibition_filter_group");
            if (n3 > 0)
            {
                s1 = s1.Substring(n3);
                n4 = s1.IndexOf("<p>");
                s1 = s1.Substring(n4 + 3);
                n4 = s1.IndexOf("</p>");
                s1 = s1.Substring(0, n4);
                st2 = s1;
                da1.Add(s1);
                //Console.WriteLine(s1);
            }
            */
            s1 = aa1[n1];
            //這邊處理比較奇怪,巨匠都同一行,tripno團號
            n3 = s1.IndexOf("ClassifyProduct.aspx?TripNo=");
            if (n3 > 0)
            {
                sa1 = s1.Split("ClassifyProduct.aspx?TripNo=");
                n3 = 0;
                n4 = sa1.Length - 1;
                while (n3 <= n4)
                {
                    aa2.Add(sa1[n3]);
                    n3++;
                }
            }
            n1++;
        }
        n1 = 0;
        n2 = aa2.Count - 1;
        while (n1 <= n2)
        {
            s1 = aa2[n1];
            s2 = s1.Substring(0, 2);
            if (s2 == "T2")
            {
                n3 = s1.IndexOf(">");
                s3 = s1.Substring(0, n3 - 1);
                aa3.Add("https://www.artisan.com.tw/ClassifyProduct.aspx?TripNo=" + s3);
            }
            n1++;
        }
        n1 = 0;
        n2 = aa3.Count - 1;
        aa2.Clear();
        using (StreamWriter sw = File.CreateText("2.txt"))
        {
            while (n1 <= n2)
            {
                aa2.Add(aa3[n1]);
                sw.WriteLine(aa3[n1]);
                n1++;
            }
        }
        aa3.Clear();
        //aa2.Clear();
        //aa2.Add("https://www.artisan.com.tw/ClassifyProduct.aspx?TripNo=T20240411000002");
        n1 = 0;
        n2 = aa2.Count - 1;
        //n2 = 0;
        while (n1 <= n2)
        {
            //先找st2                        
            s1 = aa2[n1];
            sa1 = s1.Split('/');
            n3 = sa1.Length - 1;
            s2 = sa1[n3];
            sa1 = s2.Split('=');
            n3 = sa1.Length - 1;
            s2 = sa1[n3];
            //Console.WriteLine(s2);
            n3 = 0;
            n4 = aa1.Count - 1;
            while (n3 <= n4)
            {
                s1 = aa1[n3];
                if (s1.IndexOf(s2) > 0)
                {
                    //Console.WriteLine("aa");
                    n5 = 0;
                    n6 = n3;
                    n3 = 99999;
                    while (n5 <= n6)
                    {
                        s1 = aa1[n5];
                        n7 = s1.IndexOf("class=" + "\"" + "Exhibition_filter_group");
                        if (n7 > 0)
                        {
                            s1 = s1.Substring(n7);
                            n8 = s1.IndexOf("<p>");
                            s1 = s1.Substring(n8 + 3);
                            n8 = s1.IndexOf("</p>");
                            s1 = s1.Substring(0, n8);
                            st2 = s1;
                        }
                        n5++;
                    }
                }
                n3++;
            }
            surl2=aa2[n1];
            s1 = t1.RunData(surl, surl2, st1, st2);
            n1++;
        }

    }
}