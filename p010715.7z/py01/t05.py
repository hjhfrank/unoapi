from selenium import webdriver
from selenium.webdriver.common.by import By
driver=webdriver.Firefox()    
driver.get('https://www.ystravel.com.tw/austria-czech-hungary')
html = driver.page_source
with open("t05.txt", "w",encoding="utf-8") as file:
    file.write(html)
#print('網頁內容', html)
# 關閉selenium(瀏覽器會被關閉)以節省記憶體
driver.quit()
 