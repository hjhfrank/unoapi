import requests
import io
from selenium import webdriver
from selenium.webdriver.common.by import By
import pyscreenshot as ImageGrab
#import ddddocr     
from PIL import Image
import pytesseract
import time

def findss(s1,s2):
    n1=0
    try:
       n1=s1.index(s2)    
    except:
       n1=-1
    #print(n1)   
    return n1    
#鳳凰旅遊所有產品都放在陣列裡面,順著路徑下去就對了
baseurl="https://www.travel.com.tw/"
urllist=[]
urllist.append("https://www.travel.com.tw/HALL/Index/EU")
urllist.append("https://www.travel.com.tw/HALL/Index/AM")
urllist.append("https://www.travel.com.tw/HALL/Index/RU")
urllist.append("https://www.travel.com.tw/HALL/Index/OO")
urllist.append("https://www.travel.com.tw/HALL/Index/SM")
urllist.append("https://www.travel.com.tw/hall/index/IN")
urllist.append("https://www.travel.com.tw/HALL/Index/FA")
urllist.append("https://www.travel.com.tw/HALL/Index/SS")
urllist.append("https://www.travel.com.tw/HALL/Index/SN")
urllist.append("https://www.travel.com.tw/hall/index/KR")
urllist.append("https://www.travel.com.tw/HALL/Index/CN")
urllist.append("https://www.travel.com.tw/HALL/Index/PT")
url=urllist[0]
list1=[]
x = requests.get(url)
s1=x.text
with open("t03.txt", "w",encoding="utf-8") as file:
    file.write(s1)
file1 = open('t03.txt', 'r',encoding="utf-8")
Lines = file1.readlines()    
file1.close
for line in Lines: 
    #print(line) 
    if findss(line,"<a href=")>0:
        if findss(line,"/TOU/TOU0010/")>0:
            if findss(line,"https://")<0:
                #list1.append(line)    
                s1=line
                s1=s1[findss(s1,"<a href=")+9:]
                s1=s1[0:findss(s1,'"')]                           
                list1.append(s1+'\n')
file1=open("t031.txt", "w",encoding="utf-8")
file1.writelines(list1)    
file1.close       
