from selenium import webdriver
from selenium.webdriver.common.by import By
import requests
import io

def findss(s1,s2):
    n1=0
    try:
       n1=s1.index(s2)    
    except:
       n1=-1
    #print(n1)   
    return n1      

#https://www.artisan.com.tw/ClassifyProduct.aspx?TripNo=T20231127000003
url="https://www.artisan.com.tw/"
urllist=[]
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=1")
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=2")
urllist.append("https://www.artisan.com.tw/ClassifyProduct.aspx?l=l&area=6")



driver=webdriver.Firefox()    
driver.get(urllist[0])
html = driver.page_source
with open("t06.txt", "w",encoding="utf-8") as file:
    file.write(html)
driver.quit()