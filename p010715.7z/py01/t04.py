import requests
import io
from selenium import webdriver
from selenium.webdriver.common.by import By

def findss(s1,s2):
    n1=0
    try:
       n1=s1.index(s2)    
    except:
       n1=-1   
    return n1    

baseurl="https://www.ystravel.com.tw/"
urllist=[]
urllist.append("https://www.ystravel.com.tw/austrian-czech")
urllist.append("https://www.ystravel.com.tw/austria-czech-hungary")
urllist.append("https://www.ystravel.com.tw/croatia-balkans") 
urllist.append("https://www.ystravel.com.tw/poland") 
urllist.append("https://www.ystravel.com.tw/bulgaria-romania") 
urllist.append("https://www.ystravel.com.tw/france")
urllist.append("https://www.ystravel.com.tw/germany-switzerland")
urllist.append("https://www.ystravel.com.tw/france-switzerland") 
urllist.append("https://www.ystravel.com.tw/england-scotland-ireland") 
urllist.append("https://www.ystravel.com.tw/germany")
urllist.append("https://www.ystravel.com.tw/switzerland") 
urllist.append("https://www.ystravel.com.tw/hebi") 
urllist.append("https://www.ystravel.com.tw/netherlands-belgium-luxembourg") 
urllist.append("https://www.ystravel.com.tw/netherlands-belgium-fracne") 
urllist.append("https://www.ystravel.com.tw/netherlands-belgium-germany") 
urllist.append("https://www.ystravel.com.tw/western-european-countries") 
urllist.append("https://www.ystravel.com.tw/alps") 
urllist.append("https://www.ystravel.com.tw/spain")
urllist.append("https://www.ystravel.com.tw/spain-portugal/") 
urllist.append("https://www.ystravel.com.tw/spain-portugal-morocco/") 
urllist.append("https://www.ystravel.com.tw/portugal/")
urllist.append("https://www.ystravel.com.tw/italy/") 
urllist.append("https://www.ystravel.com.tw/nordic-countries/") 
urllist.append("https://www.ystravel.com.tw/nordic-aurora") 
list1=[]
n1=0       
n2=len(urllist)-1
while (n1<=n2):
    driver = webdriver.Firefox()
    driver.get(urllist[n1])
    s1 = driver.page_source
    with open("t04v.txt", "w",encoding="utf-8") as file:
        file.write(s1)
    driver.quit()
    file1 = open('t04v.txt', 'r',encoding="utf-8")
    Lines = file1.readlines()    
    file1.close
    for line in Lines:      
        if (findss(line,'<a href="/products/group/mold/')>0) or ((findss(line,'<a href="https://www.ystravel.com.tw/products/group/mold/')>0)) or ((findss(line,'<a href="/products/group/mold-new/')>0)) or ((findss(line,'<a href="https://www.ystravel.com.tw/products/group/mold-new/')>0)):         
            list1.append(line)
    n1=n1+1
with open("t043.txt", "w",encoding="utf-8") as file:
    file.writelines(list1)      