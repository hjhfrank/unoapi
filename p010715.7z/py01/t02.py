import requests
import io

def findss(s1,s2):
    n1=0
    try:
       n1=s1.index(s2)    
    except:
       n1=-1
    #print(n1)   
    return n1      


#鳳凰旅遊,每個網站特徵不一樣
#https://www.ystravel.com.tw/永信
#https://www.artisan.com.tw/ 巨匠旅遊
url = "https://www.travel.com.tw/"
x = requests.get(url)
s1=x.text
list1=[]
list2=[]
with open("t02.txt", "w",encoding="utf-8") as file:
    file.write(s1)
file1 = open('t02.txt', 'r',encoding="utf-8")
Lines = file1.readlines()    
file1.close
for line in Lines: 
    #print(line) 
    if findss(line,"<a href=")>0:
        if findss(line,"javascript")<0:
            list1.append(line)
n1=0        
n2=len(list1)-1    
while (n1<=n2):
    s1=list1[n1]
    if findss(s1,"鳳凰年度講座")>0:
        n1=999
    else:
        list2.append(list1[n1])   
    n1=n1+1         
file1=open("t021.txt", "w",encoding="utf-8")
file1.writelines(list2)    
file1.close
    